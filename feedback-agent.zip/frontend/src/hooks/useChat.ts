import { useState, useCallback } from "react";
import { api } from "../api/chat";
import type { Message, ChatResponse } from "../types/types";

export function useChat(sessionId: string | null) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const send = useCallback(
    async (text: string) => {
      if (!sessionId || !text.trim()) return;

      const userMsg: Message = {
        id: crypto.randomUUID(),
        role: "user",
        content: text,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, userMsg]);
      setSending(true);
      setError(null);

      try {
        const data: ChatResponse = await api.sendMessage({
          session_id: sessionId,
          message: text,
        });

        const assistantMsg: Message = {
          id: data.message_id,
          role: "assistant",
          content: data.reply,
          case: data.case,
          trace: data.agent_trace,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, assistantMsg]);
      } catch (e) {
        setError(e instanceof Error ? e.message : "发送失败");
      } finally {
        setSending(false);
      }
    },
    [sessionId],
  );

  return { messages, sending, error, send, setMessages };
}
