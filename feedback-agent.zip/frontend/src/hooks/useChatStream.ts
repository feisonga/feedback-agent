import { useState, useCallback, useRef, useEffect } from "react";
import type { Message, ReActTrace, ReActStep } from "../types/types";
import { isReActTrace } from "../types/types";

interface StreamState {
  messages: Message[];
  sending: boolean;
  reactSteps: ReActStep[];
}

export function useChatStream(sessionId: string | null) {
  const [state, setState] = useState<StreamState>({
    messages: [],
    sending: false,
    reactSteps: [],
  });
  const [error, setError] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const pendingRef = useRef<string | null>(null);

  const connect = useCallback(() => {
    if (!sessionId) return;
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws/chat/${sessionId}`;

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      if (pendingRef.current) {
        ws.send(JSON.stringify({ type: "message", content: pendingRef.current }));
        pendingRef.current = null;
      }
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      handleEvent(data);
    };

    ws.onclose = () => {
      wsRef.current = null;
    };

    ws.onerror = () => {
      setError("WebSocket 连接异常");
    };
  }, [sessionId]);

  const disconnect = useCallback(() => {
    wsRef.current?.close();
    wsRef.current = null;
  }, []);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  const handleEvent = useCallback((event: Record<string, unknown>) => {
    switch (event.type) {
      // ═══ ReAct Events (v2.0) ═══
      case "react_step": {
        const step: ReActStep = {
          step: event.step as number,
          thought: event.thought as string || "",
          tool_calls: (event.tool_calls as any[]) || [],
          observations: (event.observations as any[]) || [],
          latency_ms: event.latency_ms as number,
        };
        setState((s) => ({
          ...s,
          reactSteps: [...s.reactSteps, step],
        }));
        break;
      }

      case "message_complete": {
        const reply = event.reply as string;
        const totalLatency = event.total_latency_ms as number;
        const totalToolCalls = event.total_tool_calls as number;

        setState((s) => {
          const trace: ReActTrace = {
            steps: s.reactSteps,
            total_latency_ms: totalLatency,
            total_tool_calls: totalToolCalls,
          };

          const assistantMsg: Message = {
            id: crypto.randomUUID(),
            role: "assistant",
            content: reply,
            case: "llm_react",
            trace,
            timestamp: new Date(),
          };

          return {
            ...s,
            sending: false,
            messages: [...s.messages, assistantMsg],
            reactSteps: [],
          };
        });
        break;
      }

      // ═══ Legacy Events (v1.0, kept for backward compat) ═══
      case "phase_start":
      case "phase_end":
      case "agent_done":
      case "dispatch":
        // Legacy events: silently accept, new UI only uses react_step
        break;

      case "token": {
        const token = event.content as string;
        setState((s) => {
          const msgs = [...s.messages];
          const last = msgs[msgs.length - 1];
          if (last && last.role === "assistant") {
            last.content += token;
          }
          return { ...s, messages: msgs };
        });
        break;
      }

      case "error":
        setError(event.message as string);
        setState((s) => ({ ...s, sending: false }));
        break;

      case "message_end":
        break;

      default:
        break;
    }
  }, []);

  const send = useCallback(
    (text: string) => {
      if (!text.trim()) return;

      const userMsg: Message = {
        id: crypto.randomUUID(),
        role: "user",
        content: text,
        timestamp: new Date(),
      };

      setState((s) => ({
        ...s,
        sending: true,
        messages: [...s.messages, userMsg],
        reactSteps: [],
      }));
      setError(null);

      const ws = wsRef.current;
      if (ws?.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: "message", content: text }));
      } else {
        pendingRef.current = text;
        connect();
      }
    },
    [connect],
  );

  return {
    messages: state.messages,
    sending: state.sending,
    error,
    reactSteps: state.reactSteps,
    send,
  };
}
