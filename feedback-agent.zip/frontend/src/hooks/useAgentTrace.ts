import { useState, useCallback } from "react";
import type { TracePayload, ReActTrace, ReActStep } from "../types/types";
import { isReActTrace } from "../types/types";

export interface ReActTraceView {
  steps: ReActStep[];
  totalLatency: number;
  totalToolCalls: number;
  errors: string[];
  type: "react";
}

export interface LegacyTraceView {
  phase1: { agent_name: string; result: unknown; confidence: number; evidence: string[] }[];
  phase2: { agent_name: string; result: unknown; confidence: number; evidence: string[] }[];
  decision: { case: string; reasoning: string };
  latency_ms: number;
  type: "legacy";
}

export type TraceView = ReActTraceView | LegacyTraceView;

export function useAgentTrace() {
  const [selectedTrace, setSelectedTrace] = useState<TracePayload | null>(null);

  const viewTrace = useCallback((trace: TracePayload) => {
    setSelectedTrace(trace);
  }, []);

  const clearTrace = useCallback(() => setSelectedTrace(null), []);

  const buildTraceView = (trace: TracePayload): TraceView => {
    if (isReActTrace(trace)) {
      return {
        steps: trace.steps,
        totalLatency: trace.total_latency_ms,
        totalToolCalls: trace.total_tool_calls,
        errors: trace.errors || [],
        type: "react",
      };
    }
    return {
      phase1: trace.phase1,
      phase2: trace.phase2,
      decision: trace.decision,
      latency_ms: trace.latency_ms,
      type: "legacy",
    };
  };

  return {
    selectedTrace,
    viewTrace,
    clearTrace,
    buildTraceView,
  };
}
