import type { Envelope } from "../types/types";

const API_BASE = "/";

export class ApiError extends Error {
  constructor(
    public code: number,
    message: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!res.ok) {
    throw new ApiError(res.status, `HTTP ${res.status}`);
  }

  const envelope: Envelope<T> = await res.json();
  if (envelope.code !== 0) {
    throw new ApiError(envelope.code, envelope.message);
  }

  return envelope.data;
}
