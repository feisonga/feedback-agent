import { request } from "./client";
import type {
  SessionCreateResponse,
  ChatRequest,
  ChatResponse,
  AnalyticsOverview,
  AgentPerformance,
  PaginatedResponse,
  ConversationItem,
  ConversationDetail,
} from "../types/types";

export const api = {
  health: () => request<{ status: string; agents_loaded: string[] }>("health"),

  createSession: () =>
    request<SessionCreateResponse>("api/sessions", { method: "POST", body: "{}" }),

  getSession: (id: string) =>
    request<{ session_id: string; conversation_id: string; status: string }>(`api/sessions/${id}`),

  sendMessage: (body: ChatRequest) =>
    request<ChatResponse>("api/chat/send", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  analyticsOverview: (days?: number) =>
    request<AnalyticsOverview>(`api/analytics/overview${days ? `?days=${days}` : ""}`),

  agentPerformance: (days?: number) =>
    request<AgentPerformance[]>(`api/analytics/agent-performance${days ? `?days=${days}` : ""}`),

  listConversations: (page = 1, pageSize = 20) =>
    request<PaginatedResponse<ConversationItem>>(`api/conversations?page=${page}&page_size=${pageSize}`),

  getConversation: (id: string) =>
    request<ConversationDetail>(`api/conversations/${id}`),

  deleteConversation: (id: string) =>
    request<{ deleted: string }>(`api/conversations/${id}`, { method: "DELETE" }),
};
