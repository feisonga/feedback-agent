// ── Envelope ──
export interface Envelope<T> {
  code: number;
  message: string;
  data: T;
  request_id: string;
}

// ── Session ──
export interface SessionCreateResponse {
  session_id: string;
  conversation_id: string;
  created_at: string;
}

// ── Chat ──
export interface ChatRequest {
  session_id: string;
  message: string;
  context?: Record<string, unknown>;
}

// ── ReAct Trace (v2.0 LLM-native) ──
export interface ReActToolCall {
  name: string;
  arguments: Record<string, unknown>;
}

export interface ReActObservation {
  tool: string;
  success: boolean;
  data: unknown;
  confidence?: number;
}

export interface ReActStep {
  step: number;
  thought: string;
  tool_calls: ReActToolCall[];
  observations: ReActObservation[];
  latency_ms: number;
}

export interface ReActTrace {
  steps: ReActStep[];
  total_latency_ms: number;
  total_tool_calls: number;
  errors?: string[];
}

// ── Legacy Trace (v1.0 symbolic) ──
export interface AgentTraceItem {
  agent_name: string;
  result: unknown;
  confidence: number;
  evidence: string[];
}

export interface Decision {
  case: string;
  reasoning: string;
}

export interface LegacyTracePayload {
  phase1: AgentTraceItem[];
  phase2: AgentTraceItem[];
  decision: Decision;
  latency_ms: number;
}

// ── Unified Trace (support both v1 and v2) ──
export type TracePayload = ReActTrace | LegacyTracePayload;

export function isReActTrace(trace: TracePayload): trace is ReActTrace {
  return "steps" in trace && Array.isArray((trace as ReActTrace).steps);
}

// ── Chat Response ──
export interface ChatResponse {
  message_id: string;
  session_id: string;
  reply: string;
  case: string;
  intent: string | null;
  sentiment: string | null;
  urgency: string | null;
  agent_trace: TracePayload;
}

// ── Message (UI model) ──
export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  case?: string;
  trace?: TracePayload;
  timestamp: Date;
}

// ── WebSocket Events (v2.0 ReAct) ──
export interface WsReActStepEvent {
  type: "react_step";
  step: number;
  thought: string;
  tool_calls: { name: string; arguments: Record<string, unknown> }[];
  observations: { tool: string; success: boolean; data: unknown }[];
  latency_ms: number;
}

export type WsServerEvent =
  | WsReActStepEvent
  | { type: "message_complete"; reply: string; total_latency_ms: number; total_tool_calls: number }
  | { type: "message_end" }
  | { type: "error"; message: string }
  | { type: "pong" }
  // Legacy v1 events
  | { type: "phase_start"; phase: number }
  | { type: "phase_end"; phase: number }
  | { type: "agent_done"; agent: string; confidence: number; result: unknown }
  | { type: "dispatch"; case: string; reasoning: string }
  | { type: "token"; content: string }
  | { type: "message_complete"; reply: string; case: string; latency_ms: number; needs_llm?: boolean };

export type WsClientEvent =
  | { type: "message"; content: string }
  | { type: "ping" };

// ── Analytics ──
export interface AnalyticsOverview {
  total_sessions: number;
  total_messages: number;
  avg_latency_ms: number;
  case_distribution: {
    case_a: number;
    case_b: number;
    case_c: number;
    llm_react?: number;
    case_a_pct: number;
    case_b_pct: number;
    case_c_pct: number;
    llm_react_pct?: number;
  };
  intent_distribution: Record<string, number>;
  sentiment_distribution: Record<string, number>;
}

export interface AgentPerformance {
  agent_name: string;
  total_calls: number;
  avg_confidence: number;
  confidence_sum: number;
  cases: Record<string, number>;
}

// ── Conversations ──
export interface ConversationItem {
  id: string;
  title: string;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface ConversationMessage {
  id: string;
  role: string;
  content: string;
  intent: string | null;
  sentiment: string | null;
  urgency: string | null;
  agent_trace: TracePayload | null;
  dispatch_case: string | null;
  latency_ms: number | null;
  created_at: string;
}

export interface ConversationDetail {
  id: string;
  title: string;
  status: string;
  created_at: string;
  updated_at: string;
  messages: ConversationMessage[];
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
}
