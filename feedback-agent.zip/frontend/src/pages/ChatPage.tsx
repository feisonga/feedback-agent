import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ChatWindow } from "../components/chat/ChatWindow";
import { ChatInput } from "../components/chat/ChatInput";
import { useChatStream } from "../hooks/useChatStream";
import { api } from "../api/chat";
import { AlertCircle, Cpu, Loader2, Brain, Zap } from "lucide-react";
import { ConfidenceBar } from "../components/debug/ConfidenceBar";

export function ChatPage() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);

  const { messages, sending, error, reactSteps, send } =
    useChatStream(ready ? (sessionId ?? null) : null);

  useEffect(() => {
    if (sessionId && sessionId !== "new") {
      api.getSession(sessionId).then(() => setReady(true)).catch(() => {
        api.createSession().then((data) => {
          navigate(`/chat/${data.session_id}`, { replace: true });
        }).catch((e) => setInitError(e.message));
      });
    } else {
      api.createSession().then((data) => {
        navigate(`/chat/${data.session_id}`, { replace: true });
      }).catch((e) => setInitError(e.message));
    }
  }, [sessionId, navigate]);

  if (initError) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <AlertCircle className="mx-auto mb-3 text-red-400" size={32} />
          <p className="text-gray-600 font-medium">连接失败</p>
          <p className="text-sm text-gray-400 mt-1">{initError}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm"
          >
            重试
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-200 bg-white flex items-center gap-3">
        <div>
          <h2 className="text-sm font-semibold text-gray-800">
            <span className="inline-flex items-center gap-1.5">
              <Brain size={14} className="text-indigo-500" />
              智能客服对话
              <span className="text-[10px] px-1 py-0.5 bg-indigo-100 text-indigo-600 rounded">ReAct</span>
            </span>
          </h2>
          <p className="text-xs text-gray-400">
            {ready ? `会话 ${sessionId?.slice(0, 8)}...` : "连接中..."}
          </p>
        </div>

        {sending && (
          <div className="ml-auto flex items-center gap-2 px-2 py-1 bg-indigo-50 text-indigo-600 rounded text-xs">
            <Loader2 size={12} className="animate-spin" />
            AI 推理中...
          </div>
        )}

        {error && (
          <div className="ml-auto flex items-center gap-1 text-xs text-red-500">
            <AlertCircle size={12} />
            {error}
          </div>
        )}
      </div>

      {/* ReAct Live Trace Feed */}
      {reactSteps.length > 0 && (
        <div className="px-3 py-2 bg-indigo-50 border-b border-indigo-200 space-y-1">
          <div className="flex items-center gap-1.5 text-[10px] text-indigo-500 mb-1">
            <Zap size={10} />
            ReAct 推理链路
          </div>
          {reactSteps.map((step, i) => (
            <div key={i} className="flex items-center gap-2 text-xs">
              <span className="w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center text-[9px] font-bold shrink-0">
                {step.step}
              </span>
              {step.thought && (
                <span className="text-gray-500 truncate max-w-[200px]">
                  {step.thought}
                </span>
              )}
              {step.tool_calls.map((tc, j) => (
                <span key={j} className="flex items-center gap-1 text-indigo-600 shrink-0">
                  <Cpu size={10} />
                  {tc.name}
                </span>
              ))}
            </div>
          ))}
        </div>
      )}

      {/* Messages */}
      <ChatWindow messages={messages} sending={sending} />

      {/* Input */}
      <ChatInput onSend={send} disabled={sending || !ready} />
    </div>
  );
}
