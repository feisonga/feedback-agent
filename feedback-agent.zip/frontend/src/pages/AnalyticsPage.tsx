import { useQuery } from "@tanstack/react-query";
import { BarChart3, MessageSquare, Zap, AlertTriangle, Loader2 } from "lucide-react";
import { api } from "../api/chat";

export function AnalyticsPage() {
  const overview = useQuery({
    queryKey: ["analytics-overview"],
    queryFn: () => api.analyticsOverview(),
    refetchInterval: 30_000,
  });

  const agentPerf = useQuery({
    queryKey: ["agent-performance"],
    queryFn: () => api.agentPerformance(),
    refetchInterval: 60_000,
  });

  const data = overview.data;

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-gray-200 bg-white">
        <h2 className="text-sm font-semibold text-gray-800">分析面板</h2>
        <p className="text-xs text-gray-400">系统运行概览</p>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto">
          {/* Stat Cards */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <StatCard
              icon={<MessageSquare size={20} />}
              label="总会话数"
              value={overview.isLoading ? "…" : String(data?.total_sessions ?? "--")}
              color="blue"
            />
            <StatCard
              icon={<Zap size={20} />}
              label="平均延迟"
              value={overview.isLoading ? "…" : `${data?.avg_latency_ms ?? "--"}ms`}
              color="emerald"
            />
            <StatCard
              icon={<BarChart3 size={20} />}
              label="Case A 占比"
              value={overview.isLoading ? "…" : `${data?.case_distribution.case_a_pct ?? "--"}%`}
              color="amber"
            />
            <StatCard
              icon={<AlertTriangle size={20} />}
              label="Case C 占比"
              value={overview.isLoading ? "…" : `${data?.case_distribution.case_c_pct ?? "--"}%`}
              color="red"
            />
          </div>

          {/* Case Distribution */}
          <div className="bg-white border border-gray-200 rounded-xl p-6 mb-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-4">Case 分布</h3>
            {overview.isLoading ? (
              <div className="flex justify-center py-8"><Loader2 size={24} className="animate-spin text-gray-300" /></div>
            ) : data ? (
              <div className="space-y-3">
                <CaseRow label="Case A · 规则直出" count={data.case_distribution.case_a} pct={data.case_distribution.case_a_pct} color="emerald" />
                <CaseRow label="Case B · 模板+润色" count={data.case_distribution.case_b} pct={data.case_distribution.case_b_pct} color="amber" />
                <CaseRow label="Case C · LLM 生成" count={data.case_distribution.case_c} pct={data.case_distribution.case_c_pct} color="red" />
              </div>
            ) : (
              <p className="text-center text-gray-400 py-4 text-sm">暂无数据</p>
            )}
          </div>

          {/* Intent / Sentiment */}
          <div className="grid grid-cols-2 gap-6 mb-6">
            <div className="bg-white border border-gray-200 rounded-xl p-6">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">意图分布</h3>
              {data?.intent_distribution && Object.keys(data.intent_distribution).length > 0 ? (
                <div className="space-y-2">
                  {Object.entries(data.intent_distribution).map(([k, v]) => (
                    <div key={k} className="flex justify-between text-sm">
                      <span className="text-gray-600">{k}</span>
                      <span className="font-mono text-gray-800">{v}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-gray-400 py-4 text-sm">暂无数据</p>
              )}
            </div>
            <div className="bg-white border border-gray-200 rounded-xl p-6">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">情感分布</h3>
              {data?.sentiment_distribution && Object.keys(data.sentiment_distribution).length > 0 ? (
                <div className="space-y-2">
                  {Object.entries(data.sentiment_distribution).map(([k, v]) => (
                    <div key={k} className="flex justify-between text-sm">
                      <span className="text-gray-600">{k}</span>
                      <span className="font-mono text-gray-800">{v}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-gray-400 py-4 text-sm">暂无数据</p>
              )}
            </div>
          </div>

          {/* Agent Performance */}
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-4">Agent 性能</h3>
            {agentPerf.isLoading ? (
              <div className="flex justify-center py-8"><Loader2 size={24} className="animate-spin text-gray-300" /></div>
            ) : agentPerf.data && agentPerf.data.length > 0 ? (
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-gray-400">
                    <th className="pb-2 font-medium">Agent</th>
                    <th className="pb-2 font-medium text-right">调用次数</th>
                    <th className="pb-2 font-medium text-right">平均置信度</th>
                    <th className="pb-2 font-medium text-right">Case A/C</th>
                  </tr>
                </thead>
                <tbody>
                  {agentPerf.data.map((a) => (
                    <tr key={a.agent_name} className="border-t border-gray-100">
                      <td className="py-2 text-gray-700">{a.agent_name}</td>
                      <td className="py-2 text-right font-mono">{a.total_calls}</td>
                      <td className="py-2 text-right font-mono">{(a.avg_confidence * 100).toFixed(0)}%</td>
                      <td className="py-2 text-right font-mono text-xs">
                        {a.cases?.A ?? 0}/{a.cases?.C ?? 0}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p className="text-center text-gray-400 py-4 text-sm">暂无数据</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon, label, value, color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: "blue" | "emerald" | "amber" | "red";
}) {
  const colors = {
    blue: "bg-blue-50 text-blue-600",
    emerald: "bg-emerald-50 text-emerald-600",
    amber: "bg-amber-50 text-amber-600",
    red: "bg-red-50 text-red-600",
  };
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${colors[color]}`}>
        {icon}
      </div>
      <div className="text-2xl font-bold text-gray-800">{value}</div>
      <div className="text-xs text-gray-400 mt-0.5">{label}</div>
    </div>
  );
}

function CaseRow({ label, count, pct, color }: { label: string; count: number; pct: number; color: string }) {
  const barColors: Record<string, string> = {
    emerald: "bg-emerald-500",
    amber: "bg-amber-500",
    red: "bg-red-500",
  };
  return (
    <div className="flex items-center gap-3">
      <span className="text-sm text-gray-600 w-40">{label}</span>
      <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${barColors[color]}`} style={{ width: `${Math.max(pct, 2)}%` }} />
      </div>
      <span className="text-sm font-mono text-gray-500 w-16 text-right">{count} 条</span>
      <span className="text-sm font-mono text-gray-400 w-14 text-right">{pct}%</span>
    </div>
  );
}
