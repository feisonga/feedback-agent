import { MessageSquarePlus, BarChart3 } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

export function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNewChat = async () => {
    const { api } = await import("../../api/chat");
    try {
      const data = await api.createSession();
      navigate(`/chat/${data.session_id}`);
    } catch {
      navigate("/chat/new");
    }
  };

  return (
    <aside className="w-60 bg-white border-r border-gray-200 flex flex-col shrink-0">
      <div className="p-4 border-b border-gray-100">
        <h1 className="text-lg font-bold text-gray-800">Feedback Agent</h1>
        <p className="text-xs text-gray-400 mt-0.5">智能客服反馈系统</p>
      </div>

      <div className="p-3">
        <button
          onClick={handleNewChat}
          className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 text-sm font-medium transition-colors"
        >
          <MessageSquarePlus size={16} />
          新建对话
        </button>
      </div>

      <nav className="flex-1 px-3 space-y-0.5">
        <NavItem
          icon={<MessageSquarePlus size={16} />}
          label="对话"
          active={location.pathname.startsWith("/chat")}
          onClick={() => navigate("/chat/new")}
        />
        <NavItem
          icon={<BarChart3 size={16} />}
          label="分析面板"
          active={location.pathname === "/analytics"}
          onClick={() => navigate("/analytics")}
        />
      </nav>

      <div className="p-4 border-t border-gray-100 text-xs text-gray-400">
        v0.1.0 — 规则优先 · AI 兜底
      </div>
    </aside>
  );
}

function NavItem({
  icon,
  label,
  active,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors ${
        active
          ? "bg-blue-50 text-blue-700 font-medium"
          : "text-gray-600 hover:bg-gray-100"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
