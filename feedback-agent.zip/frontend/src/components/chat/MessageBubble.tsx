import { Bot, User, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";
import type { Message } from "../../types/types";
import { isReActTrace } from "../../types/types";
import { AgentTracePanel } from "../debug/AgentTracePanel";

function traceLatency(trace: NonNullable<Message["trace"]>): number {
  if (isReActTrace(trace)) return trace.total_latency_ms;
  return (trace as { latency_ms: number }).latency_ms;
}

function traceLabel(trace: NonNullable<Message["trace"]>): string {
  if (isReActTrace(trace)) return `ReAct · ${trace.steps.length}步`;
  return `Case ${(trace as { decision: { case: string } }).decision?.case ?? "?"}`;
}

interface Props {
  message: Message;
  onViewTrace?: (trace: NonNullable<Message["trace"]>) => void;
}

export function MessageBubble({ message, onViewTrace }: Props) {
  const [showTrace, setShowTrace] = useState(false);
  const isUser = message.role === "user";

  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
          isUser ? "bg-blue-600" : "bg-emerald-600"
        }`}
      >
        {isUser ? (
          <User size={14} className="text-white" />
        ) : (
          <Bot size={14} className="text-white" />
        )}
      </div>

      <div className={`max-w-[75%] ${isUser ? "items-end" : "items-start"}`}>
        <div
          className={`rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
            isUser
              ? "bg-blue-600 text-white rounded-tr-md"
              : "bg-white border border-gray-200 text-gray-800 rounded-tl-md"
          }`}
        >
          {message.content || <span className="italic text-gray-400">思考中...</span>}
        </div>

        {!isUser && message.trace && (
          <div className="mt-1">
            <button
              onClick={() => {
                setShowTrace(!showTrace);
                if (!showTrace && message.trace && onViewTrace) {
                  onViewTrace(message.trace);
                }
              }}
              className="flex items-center gap-1 text-xs text-gray-400 hover:text-gray-600"
            >
              {showTrace ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
              Case {traceLabel(message.trace)} · {traceLatency(message.trace)}ms
            </button>
            {showTrace && message.trace && (
              <div className="mt-2">
                <AgentTracePanel trace={message.trace} />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
