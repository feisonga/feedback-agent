import { useEffect, useRef } from "react";
import type { Message } from "../../types/types";
import { MessageBubble } from "./MessageBubble";
import { TypingIndicator } from "./TypingIndicator";

interface Props {
  messages: Message[];
  sending: boolean;
  onViewTrace?: (trace: NonNullable<Message["trace"]>) => void;
}

export function ChatWindow({ messages, sending, onViewTrace }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6">
      {messages.length === 0 ? (
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="text-4xl mb-4">💬</div>
            <h2 className="text-lg font-semibold text-gray-700 mb-2">开始对话</h2>
            <p className="text-sm text-gray-400">
              发送第一条消息，智能客服将立即响应
            </p>
          </div>
        </div>
      ) : (
        <div className="max-w-3xl mx-auto space-y-4">
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} onViewTrace={onViewTrace} />
          ))}
          {sending && <TypingIndicator />}
          <div ref={bottomRef} />
        </div>
      )}
    </div>
  );
}
