import type { TracePayload, ReActTrace, LegacyTracePayload, AgentTraceItem } from "../../types/types";
import { isReActTrace } from "../../types/types";
import { ConfidenceBar } from "./ConfidenceBar";

interface Props {
  trace: TracePayload;
}

export function AgentTracePanel({ trace }: Props) {
  if (isReActTrace(trace)) {
    return <ReActTraceView trace={trace} />;
  }
  return <LegacyTraceView trace={trace} />;
}

// ═══ ReAct Trace View (v2.0 LLM-native) ═══
function ReActTraceView({ trace }: { trace: ReActTrace }) {
  return (
    <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-3 text-xs space-y-3">
      {/* Header */}
      <div className="flex items-center gap-2">
        <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-indigo-100 text-indigo-700">
          ReAct · {trace.steps.length}步推理
        </span>
        <span className="text-gray-500">
          {trace.total_tool_calls} 次工具调用
        </span>
        <span className="text-gray-400 ml-auto">
          {trace.total_latency_ms}ms
        </span>
      </div>

      {/* Steps */}
      {trace.steps.map((step, i) => (
        <ReActStepCard key={i} step={step} isLast={i === trace.steps.length - 1} />
      ))}

      {/* Errors */}
      {trace.errors && trace.errors.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded p-2 text-red-600">
          {trace.errors.map((err, i) => (
            <div key={i}>{err}</div>
          ))}
        </div>
      )}
    </div>
  );
}

function ReActStepCard({ step, isLast }: { step: ReActTrace["steps"][0]; isLast: boolean }) {
  return (
    <div className={`bg-white border rounded p-2 ${isLast ? "border-indigo-300" : "border-gray-200"}`}>
      {/* Step header */}
      <div className="flex items-center gap-2 mb-1.5">
        <span className="w-5 h-5 rounded-full bg-indigo-500 text-white flex items-center justify-center text-[10px] font-bold">
          {step.step}
        </span>
        <span className="text-gray-500">
          {step.thought ? `"${step.thought.slice(0, 60)}${step.thought.length > 60 ? "..." : ""}"` : "推理中..."}
        </span>
        <span className="text-gray-400 ml-auto">{step.latency_ms}ms</span>
      </div>

      {/* Tool Calls → Observation */}
      {step.tool_calls.length > 0 && (
        <div className="space-y-1 ml-7">
          {step.tool_calls.map((tc, j) => {
            const obs = step.observations?.[j];
            return (
              <div key={j}>
                <div className="flex items-center gap-2 py-0.5">
                  <span className="text-indigo-600">⚙ {tc.name}</span>
                  {obs && (
                    <span className={obs.success ? "text-emerald-600" : "text-red-500"}>
                      {obs.success ? "✓" : "✗"}
                    </span>
                  )}
                  {obs?.confidence != null && obs.confidence < 1 && (
                    <ConfidenceBar confidence={obs.confidence} compact />
                  )}
                </div>
                {/* Observation detail */}
                {obs?.data != null && (
                  <div className="text-gray-500 text-[10px] pl-2 border-l-2 border-indigo-200">
                    {formatObservation(obs)}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function formatObservation(obs: { tool: string; data: unknown }): string {
  const data = obs.data as Record<string, unknown>;
  if (!data) return "";

  const parts: string[] = [];

  // Intent
  if (data.intent && data.label) {
    parts.push(`意图: ${data.label} (${data.intent})`);
  } else if (data.intent) {
    parts.push(`意图: ${data.intent}`);
  }

  // Sentiment
  if (data.sentiment) {
    const intensity = data.intensity ? `·强度${data.intensity}` : "";
    parts.push(`情感: ${data.sentiment}${intensity}`);
  }

  // Urgency
  if (data.urgency) {
    const score = data.score ? `·${data.score}` : "";
    parts.push(`紧急度: ${data.urgency}${score}`);
  }

  // Entities
  if (data.entities && typeof data.entities === "object") {
    const ent = data.entities as Record<string, unknown>;
    const keys = Object.keys(ent).filter(k => ent[k]);
    if (keys.length > 0) {
      parts.push(`实体: ${keys.slice(0, 4).join(", ")}`);
    }
  }

  // FAQ / Policy / Case
  if (data.matched) {
    const matched = data.matched as Record<string, string>;
    if (matched.question) parts.push(`匹配FAQ: ${matched.question.slice(0, 50)}`);
    if (matched.title) parts.push(`匹配政策: ${matched.title}`);
    if (matched.case_id) parts.push(`匹配案例: ${matched.case_id}`);
  }

  // Dialogue
  if (data.status) {
    parts.push(`对话状态: ${data.status}`);
  }
  if (data.followup) {
    parts.push(`追问: ${data.followup}`);
  }

  return parts.join(" · ");
}


// ═══ Legacy Trace View (v1.0 symbolic) ═══
function LegacyTraceView({ trace }: { trace: LegacyTracePayload }) {
  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 text-xs space-y-3">
      {/* Decision */}
      <div className="flex items-center gap-2">
        <CaseBadge caseLabel={trace.decision.case} />
        <span className="text-gray-500">{trace.decision.reasoning}</span>
        <span className="text-gray-400 ml-auto">{trace.latency_ms}ms</span>
      </div>

      <PhaseSection title="Phase 1 · 快速判断" agents={trace.phase1} />
      <PhaseSection title="Phase 2 · 深度分析" agents={trace.phase2} />
    </div>
  );
}

function CaseBadge({ caseLabel }: { caseLabel: string }) {
  const colors: Record<string, string> = {
    A: "bg-emerald-100 text-emerald-700",
    B: "bg-amber-100 text-amber-700",
    C: "bg-red-100 text-red-700",
    llm_react: "bg-indigo-100 text-indigo-700",
  };
  return (
    <span
      className={`px-1.5 py-0.5 rounded font-bold text-[10px] ${
        colors[caseLabel] ?? "bg-gray-100 text-gray-600"
      }`}
    >
      {caseLabel === "llm_react" ? "ReAct" : `Case ${caseLabel}`}
    </span>
  );
}

function PhaseSection({
  title,
  agents,
}: {
  title: string;
  agents: AgentTraceItem[];
}) {
  return (
    <div>
      <div className="text-gray-400 font-medium mb-1.5">{title}</div>
      <div className="space-y-1.5">
        {agents.map((a) => (
          <div key={a.agent_name} className="flex items-center gap-3">
            <span className="text-gray-600 w-32 truncate">{a.agent_name}</span>
            <div className="flex-1">
              <ConfidenceBar confidence={a.confidence} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
