interface Props {
  confidence: number;
  compact?: boolean;
}

export function ConfidenceBar({ confidence, compact }: Props) {
  const pct = Math.round(confidence * 100);
  const color =
    confidence >= 0.8 ? "bg-emerald-500" : confidence >= 0.5 ? "bg-amber-500" : "bg-red-500";

  if (compact) {
    return (
      <span
        className={`text-[10px] font-mono ${
          confidence >= 0.8 ? "text-emerald-600" : confidence >= 0.5 ? "text-amber-600" : "text-red-600"
        }`}
      >
        {pct}%
      </span>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${color}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="text-xs font-mono text-gray-500 w-8 text-right">{pct}%</span>
    </div>
  );
}
