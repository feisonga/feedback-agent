import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:3102",
      "/ws": {
        target: "ws://localhost:3102",
        ws: true,
      },
      "/health": "http://localhost:3102",
    },
  },
});
