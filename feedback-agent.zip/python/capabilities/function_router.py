"""
Function Router: 意图 → 函数匹配与执行

根据意图分类结果和实体抽取结果，匹配并执行对应的函数。
执行结果以 Observation 格式返回。
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional

try:
    from .function_registry import FunctionRegistry, FunctionSchema, registry
except ImportError:
    from capabilities.function_registry import FunctionRegistry, FunctionSchema, registry


@dataclass
class FunctionResult:
    """函数执行结果（Observation 格式）"""
    function_name: str
    success: bool
    data: Any = None
    error: str = ""
    message: str = ""

    def to_observation(self) -> str:
        """转为 Observation 文本，可注入对话历史"""
        if self.success:
            return f"[函数调用] {self.function_name} 成功: {self.message}"
        return f"[函数调用] {self.function_name} 失败: {self.error}"


class FunctionRouter:

    def __init__(self, reg: FunctionRegistry = None):
        self.registry = reg or registry

    def execute(self, function_name: str, params: Dict[str, Any]) -> FunctionResult:
        """执行指定函数"""
        schema = self.registry.get(function_name)
        if not schema:
            return FunctionResult(
                function_name=function_name,
                success=False,
                error=f"未注册的函数: {function_name}",
            )
        if schema.fn is None:
            return FunctionResult(
                function_name=function_name,
                success=False,
                error=f"函数 {function_name} 无可执行实现",
            )

        try:
            result = schema.fn(**params)
            return FunctionResult(
                function_name=function_name,
                success=True,
                data=result,
                message=str(result),
            )
        except Exception as e:
            return FunctionResult(
                function_name=function_name,
                success=False,
                error=str(e),
            )

    def route(self, intent: str, entities: Dict[str, str],
              context: Dict = None) -> Optional[str]:
        """根据意图和实体决定应调用哪个函数"""
        return self.registry.find_by_entities(intent, entities)

    def auto_execute(self, intent: str, entities: Dict[str, str],
                     context: Dict = None) -> Optional[FunctionResult]:
        """自动匹配并执行函数"""
        name = self.route(intent, entities, context)
        if name is None:
            return None
        params = self._extract_params(name, entities, context)
        return self.execute(name, params)

    def _extract_params(self, function_name: str, entities: Dict[str, str],
                        context: Dict = None) -> Dict[str, Any]:
        """从实体中提取函数参数"""
        schema = self.registry.get(function_name)
        if not schema:
            return {}

        params = {}
        for req_entity in schema.required_entities:
            if req_entity in entities:
                params[req_entity] = entities[req_entity]

        for opt_entity in schema.optional_entities:
            if opt_entity in entities:
                params[opt_entity] = entities[opt_entity]

        if context:
            for key, info in schema.parameters.items():
                if key not in params and key in context:
                    params[key] = context[key]

        return params


# 全局路由实例
router = FunctionRouter()
