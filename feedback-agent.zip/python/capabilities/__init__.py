"""
能力层：RAG Pipeline + FunctionCall

所有函数通过 FunctionRegistry 注册后，由 FunctionRouter 自动匹配与执行。
"""

from capabilities.function_registry import FunctionRegistry, FunctionSchema, registry
from capabilities.function_router import FunctionRouter, FunctionResult, router


def register_all_functions():
    """注册所有可调用函数到全局注册中心"""
    from functions.order_ops import query_order, query_refund_eligibility, check_inventory
    from functions.ticket_ops import create_ticket, query_ticket_status, escalate_to_human
    from functions.customer_ops import get_customer_profile

    registry.register(FunctionSchema(
        name="query_order",
        description="查询订单状态、物流信息",
        category="order",
        trigger_intents=["inquiry", "refund"],
        required_entities=["order_id"],
        fn=query_order,
    ))

    registry.register(FunctionSchema(
        name="query_refund_eligibility",
        description="检查订单是否满足退款条件",
        category="order",
        trigger_intents=["refund"],
        required_entities=["order_id"],
        fn=query_refund_eligibility,
    ))

    registry.register(FunctionSchema(
        name="check_inventory",
        description="查询商品库存状态",
        category="order",
        trigger_intents=["inquiry"],
        required_entities=["product_name"],
        fn=check_inventory,
    ))

    registry.register(FunctionSchema(
        name="create_ticket",
        description="创建正式投诉/售后工单",
        category="ticket",
        trigger_intents=["complaint", "repair"],
        required_entities=["user_id"],
        optional_entities=["issue"],
        fn=create_ticket,
    ))

    registry.register(FunctionSchema(
        name="query_ticket_status",
        description="查询工单处理状态",
        category="ticket",
        trigger_intents=["inquiry", "complaint"],
        required_entities=["ticket_id"],
        fn=query_ticket_status,
    ))

    registry.register(FunctionSchema(
        name="escalate_to_human",
        description="转人工客服",
        category="system",
        trigger_intents=["other"],
        required_entities=[],
        fn=escalate_to_human,
    ))

    registry.register(FunctionSchema(
        name="get_customer_profile",
        description="获取用户画像（VIP等级、历史工单记录）",
        category="customer",
        trigger_intents=["inquiry", "complaint", "refund", "repair", "suggestion"],
        required_entities=[],
        optional_entities=["user_id"],
        fn=get_customer_profile,
    ))


# 自动注册
register_all_functions()
