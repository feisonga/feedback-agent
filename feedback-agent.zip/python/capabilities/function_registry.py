"""
Function Registry: 函数注册表

每个可调用函数需在此注册，包含参数 Schema 和触发条件。
使用 Pydantic 定义参数类型，支持自动函数发现。
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, get_type_hints
import inspect


@dataclass
class FunctionSchema:
    """函数元数据"""
    name: str                           # 函数名
    description: str                    # 功能描述
    category: str                       # 分类: order / ticket / customer / system
    trigger_intents: List[str]          # 触发意图
    required_entities: List[str]        # 必需的实体类型 (如 ["order_id"])
    optional_entities: List[str] = field(default_factory=list)
    parameters: Dict[str, Dict] = field(default_factory=dict)  # 参数定义
    fn: Optional[Callable] = None       # 实际函数引用

    def to_openai_function(self) -> dict:
        """转为 OpenAI Function Calling 格式"""
        props = {}
        required = []
        for name, info in self.parameters.items():
            props[name] = {
                "type": info.get("type", "string"),
                "description": info.get("description", ""),
            }
            if info.get("required", False):
                required.append(name)
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": props,
                    "required": required,
                },
            },
        }


class FunctionRegistry:
    """函数注册中心"""

    def __init__(self):
        self._functions: Dict[str, FunctionSchema] = {}
        self._by_intent: Dict[str, List[str]] = {}

    def register(self, schema: FunctionSchema):
        """注册函数"""
        if schema.fn is not None:
            schema.parameters = self._infer_parameters(schema.fn)
        self._functions[schema.name] = schema
        for intent in schema.trigger_intents:
            self._by_intent.setdefault(intent, []).append(schema.name)

    def _infer_parameters(self, fn: Callable) -> Dict[str, Dict]:
        """从函数签名推断参数定义"""
        sig = inspect.signature(fn)
        params = {}
        for name, param in sig.parameters.items():
            if name in ("self", "cls"):
                continue
            anno = param.annotation if param.annotation is not inspect.Parameter.empty else "string"
            type_map = {str: "string", int: "integer", float: "number", bool: "boolean"}
            ptype = type_map.get(anno, "string")
            required = param.default is inspect.Parameter.empty
            params[name] = {"type": ptype, "required": required, "description": ""}
        return params

    def get(self, name: str) -> Optional[FunctionSchema]:
        return self._functions.get(name)

    def find_by_intent(self, intent: str) -> List[str]:
        """根据意图查找匹配的函数名列表"""
        return self._by_intent.get(intent, [])

    def find_by_entities(self, intent: str, entities: Dict[str, str]) -> Optional[str]:
        """根据意图+实体找到最匹配的函数"""
        candidates = self.find_by_intent(intent)
        if not candidates:
            return None

        best_match = None
        best_score = 0
        for name in candidates:
            schema = self.get(name)
            if not schema:
                continue
            # 检查是否满足必需实体
            satisfied = sum(1 for e in schema.required_entities if e in entities)
            score = satisfied / max(len(schema.required_entities), 1)
            if score >= 1.0 and score > best_score:
                best_score = score
                best_match = name

        return best_match if best_match else (candidates[0] if candidates else None)

    def list_all(self) -> List[str]:
        return list(self._functions.keys())

    def get_openai_functions(self) -> List[dict]:
        return [s.to_openai_function() for s in self._functions.values() if s.fn is not None]


# 全局注册中心实例
registry = FunctionRegistry()
