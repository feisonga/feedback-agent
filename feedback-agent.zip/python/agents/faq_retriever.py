"""
Agent 6: FAQ 检索

使用 sentence-transformers + faiss 进行语义向量检索，
将用户问题与 FAQ 语料库进行相似度匹配，返回最佳匹配项。
"""

import json
import os
import numpy as np

try:
    from . import BaseAgent, AgentResult
except ImportError:
    from agents import BaseAgent, AgentResult


class FAQRetriever(BaseAgent):

    def __init__(self, corpus_path: str = None, model_name: str = None):
        super().__init__("FAQRetriever")
        self.faqs = []
        self.embeddings = None
        self.index = None
        self.model = None

        if corpus_path is None:
            corpus_path = os.path.join(os.path.dirname(__file__), "..", "knowledge", "faq_corpus.json")
        self.corpus_path = os.path.normpath(corpus_path)

        if model_name is None:
            model_name = "paraphrase-multilingual-MiniLM-L12-v2"

        self._load_corpus()
        self._load_model(model_name)
        self._build_index()

    def _load_corpus(self):
        with open(self.corpus_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.faqs = data.get("faqs", [])

    def _load_model(self, model_name: str):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)

    def _build_index(self):
        import faiss
        texts = [faq["question"] for faq in self.faqs]
        self.embeddings = self.model.encode(texts, normalize_embeddings=True)
        dim = self.embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dim)
        self.index.add(self.embeddings.astype(np.float32))

    def process(self, text: str, context: dict = None) -> AgentResult:
        if not self.faqs:
            return self._low([], "FAQ 语料库为空")

        query_emb = self.model.encode([text], normalize_embeddings=True).astype(np.float32)
        scores, indices = self.index.search(query_emb, k=3)

        top1_score = float(scores[0][0])
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0 or idx >= len(self.faqs):
                continue
            faq = self.faqs[idx]
            results.append({
                "id": faq["id"],
                "question": faq["question"],
                "answer": faq["answer"],
                "category": faq.get("category", ""),
                "similarity": round(float(score), 4),
            })

        if not results:
            return self._low([], "未找到匹配的 FAQ")

        best = results[0]
        confidence = best["similarity"]

        evidence = [
            f"最佳匹配: [{best['id']}] {best['question']} (相似度: {best['similarity']:.4f})",
        ]
        if len(results) > 1:
            evidence.append(f"次优匹配: [{results[1]['id']}] {results[1]['question']} (相似度: {results[1]['similarity']:.4f})")

        return AgentResult(
            agent_name=self.name,
            result={
                "matched": best,
                "candidates": results,
            },
            confidence=confidence,
            evidence=evidence,
            metadata={"top_k": len(results), "threshold_used": 0.5},
        )

    def reload_corpus(self):
        self._load_corpus()
        self._build_index()


if __name__ == "__main__":
    retriever = FAQRetriever()
    test_queries = [
        "我想退款，怎么操作？",
        "退货的运费谁出？",
        "收到的商品是坏的怎么办？",
        "你们的客服电话是多少？",
        "超过7天了还能退吗？",
    ]
    for q in test_queries:
        r = retriever.process(q)
        best = r.result["matched"] if r.result else {}
        print(f"Q: {q}")
        print(f"  -> [{best.get('id', '-')}] {best.get('question', '-')} (score={r.confidence:.4f})")
        print()
