"""
对话状态追踪 Agent —— 符号层，零 LLM 依赖

方法：意图→槽位映射 + 有限状态机
追踪多轮对话中已收集/缺失的信息，驱动追问逻辑。
"""
import re
from typing import Dict, List, Optional
from dataclasses import dataclass, field

try:
    from . import BaseAgent, AgentResult
except ImportError:
    from agents import BaseAgent, AgentResult  # type: ignore


@dataclass
class DialogState:
    """单次对话的状态快照"""
    session_id: str = ""
    current_intent: str = ""
    filled_slots: Dict[str, str] = field(default_factory=dict)
    missing_slots: List[str] = field(default_factory=list)
    turn_count: int = 0
    history: List[Dict] = field(default_factory=list)
    status: str = "collecting"  # collecting | ready | closed


# 意图 → 槽位映射（与 intent_patterns.yaml 同步）
INTENT_SLOTS: Dict[str, Dict[str, List[str]]] = {
    "refund": {
        "required": ["order_id", "reason"],
        "optional": ["product_name"],
    },
    "complaint": {
        "required": ["target", "description"],
        "optional": ["evidence"],
    },
    "inquiry": {
        "required": ["topic"],
        "optional": ["detail"],
    },
    "repair": {
        "required": ["product_name", "issue_description"],
        "optional": ["contact"],
    },
    "suggestion": {
        "required": ["content"],
        "optional": ["contact"],
    },
    "other": {
        "required": [],
        "optional": [],
    },
}

# 追问模板
FOLLOWUP_PROMPTS: Dict[str, str] = {
    "order_id": "请问您的订单号是什么？",
    "reason": "请问是什么原因需要处理呢？",
    "product_name": "请问是哪个商品？",
    "target": "请问您要投诉的对象是？",
    "description": "请详细描述一下您遇到的问题。",
    "evidence": "如果有相关凭证（截图/照片），方便上传一下吗？",
    "topic": "请问您想咨询什么问题？",
    "detail": "方便具体说明一下吗？",
    "issue_description": "请描述一下具体的故障情况。",
    "contact": "方便留下您的联系方式吗（手机号/邮箱）？",
    "content": "请说说您的建议或反馈。",
}


class DialogTracker(BaseAgent):

    def __init__(self):
        super().__init__("dialogue_tracker")
        self.sessions: Dict[str, DialogState] = {}

    def get_or_create(self, session_id: str) -> DialogState:
        if session_id not in self.sessions:
            self.sessions[session_id] = DialogState(session_id=session_id)
        return self.sessions[session_id]

    def _extract_slot_value(self, text: str, slot_name: str) -> Optional[str]:
        """
        尝试从用户输入中提取槽位值。
        纯符号提取，不调 LLM。
        """
        patterns = {
            "order_id": r"(?:ORD-?\d{4,}|\d{6,})",
            "reason": None,    # 原因用整句存储
            "product_name": None,
            "contact": r"(?:1[3-9]\d{9}|[\w.+-]+@[\w-]+\.[\w.-]+)",
            "description": None,
            "issue_description": None,
            "topic": None,
            "detail": None,
            "content": None,
            "target": None,
            "evidence": None,
        }
        if slot_name in patterns and patterns[slot_name]:
            m = re.search(patterns[slot_name], text)
            if m:
                return m.group(0)
        # 对无固定模式的槽位，如果用户输入够长则直接作为值
        if len(text) > 4:
            return text.strip()
        return None

    def update_intent(self, session_id: str, intent: str) -> Dict:
        """更新当前意图并重新计算缺失槽位"""
        state = self.get_or_create(session_id)
        state.current_intent = intent
        slots_cfg = INTENT_SLOTS.get(intent, {"required": [], "optional": []})
        state.missing_slots = [
            s for s in slots_cfg["required"]
            if s not in state.filled_slots
        ]
        all_filled = all(
            s in state.filled_slots and state.filled_slots[s]
            for s in slots_cfg["required"]
        )
        if all_filled:
            state.status = "ready"
        return {"state": state, "followup": self._next_followup(state)}

    def fill_slot(self, session_id: str, slot_name: str, value: str) -> Dict:
        """填充指定槽位"""
        state = self.get_or_create(session_id)
        state.filled_slots[slot_name] = value
        if slot_name in state.missing_slots:
            state.missing_slots.remove(slot_name)

        intent_slots = INTENT_SLOTS.get(state.current_intent, {"required": []})
        if not state.missing_slots:
            state.status = "ready"
        return {"state": state, "followup": self._next_followup(state)}

    def auto_fill(self, session_id: str, user_text: str) -> Dict:
        """
        自动尝试从用户输入中回填所有缺失槽位。
        返回 {filled_slots, still_missing, followup, status}
        """
        state = self.get_or_create(session_id)
        newly_filled: List[str] = []

        for slot in list(state.missing_slots):
            value = self._extract_slot_value(user_text, slot)
            if value:
                state.filled_slots[slot] = value
                state.missing_slots.remove(slot)
                newly_filled.append(slot)

        intent_slots = INTENT_SLOTS.get(state.current_intent, {"required": []})
        if not state.missing_slots:
            state.status = "ready"

        return {
            "state": state,
            "newly_filled": newly_filled,
            "still_missing": state.missing_slots,
            "followup": self._next_followup(state),
            "status": state.status,
        }

    def _next_followup(self, state: DialogState) -> Optional[str]:
        """生成下一条追问"""
        if not state.missing_slots:
            return None
        slot = state.missing_slots[0]
        return FOLLOWUP_PROMPTS.get(slot, f"请提供一下{slot}")

    def process(self, text: str, context: Optional[Dict] = None) -> AgentResult:
        if not context or "session_id" not in context:
            return self._low(
                result={"error": "缺少 session_id"},
                reason="context 中未提供 session_id",
            )

        session_id = context["session_id"]

        # 如果上下文中给出了意图，先更新
        if context.get("intent"):
            self.update_intent(session_id, context["intent"])

        # 自动回填
        filling_result = self.auto_fill(session_id, text)
        state = self.sessions[session_id]

        result = {
            "session_id": session_id,
            "current_intent": state.current_intent,
            "filled_slots": dict(state.filled_slots),
            "missing_slots": list(state.missing_slots),
            "followup": filling_result["followup"],
            "status": state.status,
            "turn_count": state.turn_count,
        }

        confidence = 0.9 if state.status == "ready" else 0.6
        return self._ok(
            result=result,
            confidence=confidence,
            evidence=[
                f"已填: {state.filled_slots}",
                f"缺失: {state.missing_slots}",
                f"状态: {state.status}",
            ],
        )

    def close(self, session_id: str):
        if session_id in self.sessions:
            self.sessions[session_id].status = "closed"


if __name__ == "__main__":
    tracker = DialogTracker()

    # 模拟多轮对话
    ctx = {"session_id": "test-001", "intent": "refund"}

    print("=== 第1轮：用户只给意图 ===")
    r = tracker.process("我要退款", ctx)
    print(f"State: {r.result}")

    print("\n=== 第2轮：用户提供订单号 ===")
    r = tracker.process("订单号 ORD-12345", ctx)
    print(f"State: {r.result}")

    print("\n=== 第3轮：用户说原因 ===")
    r = tracker.process("买的东西质量有问题", ctx)
    print(f"State: {r.result}")
