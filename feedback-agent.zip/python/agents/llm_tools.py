"""
LLM-native Agent Tools —— 将 8 个符号 Agent 改造为 LLM 可调用的 Tool

每个 Tool:
- 使用 LLM 推理替代正则/词典匹配
- 保留原符号 Agent 作为降级回退
- 输出标准化 ToolResult

LLM 驱动的优势:
- 意图识别: 理解复杂多意表达，而非关键词匹配
- 情感分析: 理解语境和反讽，而非词典计数
- 实体提取: 理解隐含实体，而非正则硬匹配
- 紧急度评估: 综合语境判断，而非关键词触发
"""
import json
import os
from typing import Dict, List, Optional

from agents import AgentResult
from core.tool_schema import ToolResult


# ── 全局 LLM 客户端引用（由注册时注入） ──
_llm_client = None
_use_llm = True


def set_llm_client(client, use_llm: bool = True):
    global _llm_client, _use_llm
    _llm_client = client
    _use_llm = use_llm


def _run_async(async_fn, *args, **kwargs):
    """安全地运行异步函数"""
    import asyncio
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(async_fn(*args, **kwargs))
    import concurrent.futures
    future = asyncio.run_coroutine_threadsafe(async_fn(*args, **kwargs), loop)
    return future.result(timeout=30)


# ═══════════════════════════════════════════════════════════════
# Tool 1: 意图分类
# ═══════════════════════════════════════════════════════════════
INTENT_CATEGORIES = [
    "refund", "complaint", "inquiry", "repair", "suggestion",
    "dispute", "elderly", "policy", "farming", "education",
    "emergency", "infrastructure", "employment", "medical",
    "environment", "other",
]
INTENT_LABELS = {
    "refund": "退款退货", "complaint": "投诉举报", "inquiry": "信息咨询",
    "repair": "报修维修", "suggestion": "建议反馈", "dispute": "纠纷调解",
    "elderly": "老人关怀", "policy": "政策咨询", "farming": "农技服务",
    "education": "教育帮扶", "emergency": "紧急求助",
    "infrastructure": "基础设施", "employment": "就业务工",
    "medical": "医疗健康", "environment": "环境卫生", "other": "其它",
}


def intent_classify(text: str, context: Dict = None) -> ToolResult:
    """LLM 驱动的意图分类"""
    if not _use_llm or not _llm_client:
        return _intent_classify_fallback(text)

    try:
        result = _run_async(_llm_client.classify(
            text=text,
            instruction="你是乡村社区服务意图分类专家。分析用户消息，判断其最可能的意图类别。如果无法确定，选 other。",
            categories=INTENT_CATEGORIES,
        ))
        intent = result.get("category", "other")
        confidence = result.get("confidence", 0.5)
        reasoning = result.get("reasoning", "")

        return ToolResult(
            tool_name="intent_classify",
            success=True,
            data={
                "intent": intent,
                "label": INTENT_LABELS.get(intent, intent),
                "confidence": confidence,
            },
            confidence=confidence,
            evidence=[reasoning] if reasoning else [],
        )
    except Exception:
        return _intent_classify_fallback(text)


def _intent_classify_fallback(text: str) -> ToolResult:
    from agents.intent_classifier import IntentClassifier
    agent = IntentClassifier()
    r = agent.process(text)
    return ToolResult(
        tool_name="intent_classify",
        success=True,
        data=r.result,
        confidence=r.confidence,
        evidence=r.evidence,
    )


# ═══════════════════════════════════════════════════════════════
# Tool 2: 情感分析
# ═══════════════════════════════════════════════════════════════
SENTIMENT_CATEGORIES = ["positive", "neutral", "negative", "urgent"]


def sentiment_analyze(text: str, context: Dict = None) -> ToolResult:
    """LLM 驱动的情感分析"""
    if not _use_llm or not _llm_client:
        return _sentiment_fallback(text)

    try:
        result = _run_async(_llm_client.classify(
            text=text,
            instruction="你是情感分析专家。分析用户消息的情感倾向。urgent=紧急/危险/威胁, negative=不满/愤怒, neutral=中性/一般, positive=满意/感谢。",
            categories=SENTIMENT_CATEGORIES,
        ))
        sentiment = result.get("category", "neutral")
        confidence = result.get("confidence", 0.6)
        # 从 reasoning 中提取强度
        reasoning = result.get("reasoning", "")
        intensity = 0.8 if sentiment in ("urgent", "negative") else (0.5 if sentiment == "positive" else 0.1)

        return ToolResult(
            tool_name="sentiment_analyze",
            success=True,
            data={"sentiment": sentiment, "intensity": intensity},
            confidence=confidence,
            evidence=[reasoning] if reasoning else [],
        )
    except Exception:
        return _sentiment_fallback(text)


def _sentiment_fallback(text: str) -> ToolResult:
    from agents.sentiment_analyzer import SentimentAnalyzer
    agent = SentimentAnalyzer()
    r = agent.process(text)
    return ToolResult(
        tool_name="sentiment_analyze",
        success=True,
        data=r.result,
        confidence=r.confidence,
        evidence=r.evidence,
    )


# ═══════════════════════════════════════════════════════════════
# Tool 3: 实体提取
# ═══════════════════════════════════════════════════════════════


def entity_extract(text: str, context: Dict = None) -> ToolResult:
    """LLM 驱动的实体提取"""
    if not _use_llm or not _llm_client:
        return _entity_fallback(text)

    try:
        result = _run_async(_llm_client.extract(
            text=text,
            instruction="从用户消息中提取关键实体信息。提取所有可识别的实体，包括但不限于：订单号、手机号、邮箱、地址、金额、日期、商品名、快递单号、人员姓名等。",
            schema={
                "order_id": "订单号 (如 ORD-12345)",
                "phone": "手机号",
                "email": "邮箱地址",
                "address": "地址",
                "amount": "金额",
                "date": "日期",
                "product_name": "商品名称",
                "tracking_number": "快递单号",
                "person_name": "人员姓名",
                "organization": "机构/商家名称",
                "other_entities": "其它重要实体",
            },
        ))
        # 清理空值
        entities = {k: v for k, v in result.items() if v and v != "null"}
        total = sum(1 for v in entities.values() if v)

        return ToolResult(
            tool_name="entity_extract",
            success=True,
            data={"entities": entities, "total": total},
            confidence=min(0.95, 0.5 + total * 0.15),
        )
    except Exception:
        return _entity_fallback(text)


def _entity_fallback(text: str) -> ToolResult:
    from agents.entity_extractor import EntityExtractor
    agent = EntityExtractor()
    r = agent.process(text)
    return ToolResult(
        tool_name="entity_extract",
        success=True,
        data=r.result,
        confidence=r.confidence,
        evidence=r.evidence,
    )


# ═══════════════════════════════════════════════════════════════
# Tool 4: 紧急度评估
# ═══════════════════════════════════════════════════════════════
URGENCY_CATEGORIES = ["low", "medium", "high", "critical"]


def urgency_assess(text: str, context: Dict = None) -> ToolResult:
    """LLM 驱动的紧急度评估"""
    if not _use_llm or not _llm_client:
        return _urgency_fallback(text, context)

    try:
        sentiment_hint = ""
        if context and "sentiment" in context:
            sentiment_hint = f"\n已知情感状态: {context['sentiment']}"
        if context and "intent" in context:
            sentiment_hint += f"\n已知意图: {context['intent']}"

        result = _run_async(_llm_client.classify(
            text=f"{text}{sentiment_hint}",
            instruction="评估用户问题的紧急程度。critical=生命安全/重大安全/可能引发舆情, high=强烈不满/要求立即处理/涉及投诉举报, medium=一般问题/需要处理但有时间缓冲, low=普通咨询/建议/闲聊。",
            categories=URGENCY_CATEGORIES,
        ))
        urgency = result.get("category", "low")
        confidence = result.get("confidence", 0.5)
        score_map = {"critical": 0.95, "high": 0.7, "medium": 0.45, "low": 0.15}
        score = score_map.get(urgency, 0.15)

        return ToolResult(
            tool_name="urgency_assess",
            success=True,
            data={"urgency": urgency, "score": score},
            confidence=confidence,
            evidence=[result.get("reasoning", "")],
        )
    except Exception:
        return _urgency_fallback(text, context)


def _urgency_fallback(text: str, context: Dict = None) -> ToolResult:
    from agents.urgency_assessor import UrgencyAssessor
    agent = UrgencyAssessor()
    r = agent.process(text, context=context)
    return ToolResult(
        tool_name="urgency_assess",
        success=True,
        data=r.result,
        confidence=r.confidence,
        evidence=r.evidence,
    )


# ═══════════════════════════════════════════════════════════════
# Tool 5: FAQ 检索
# ═══════════════════════════════════════════════════════════════


def faq_retrieve(text: str, context: Dict = None) -> ToolResult:
    """FAQ 语义检索（保留向量检索，增强结果摘要）"""
    try:
        from agents.faq_retriever import FAQRetriever
        agent = FAQRetriever()
        r = agent.process(text)
        return ToolResult(
            tool_name="faq_retrieve",
            success=True,
            data=r.result,
            confidence=r.confidence,
            evidence=r.evidence,
        )
    except Exception as e:
        return ToolResult(
            tool_name="faq_retrieve",
            success=False,
            error=str(e),
        )


# ═══════════════════════════════════════════════════════════════
# Tool 6: 政策匹配
# ═══════════════════════════════════════════════════════════════


def policy_search(text: str, context: Dict = None) -> ToolResult:
    """政策文档 BM25 检索"""
    try:
        from agents.policy_matcher import PolicyMatcher
        agent = PolicyMatcher()
        r = agent.process(text)
        return ToolResult(
            tool_name="policy_search",
            success=True,
            data=r.result,
            confidence=r.confidence,
            evidence=r.evidence,
        )
    except Exception as e:
        return ToolResult(
            tool_name="policy_search",
            success=False,
            error=str(e),
        )


# ═══════════════════════════════════════════════════════════════
# Tool 7: 相似案例检索
# ═══════════════════════════════════════════════════════════════


def similar_case_search(text: str, context: Dict = None) -> ToolResult:
    """历史工单语义检索"""
    try:
        from agents.similar_case import SimilarCaseRetriever
        agent = SimilarCaseRetriever()
        r = agent.process(text)
        return ToolResult(
            tool_name="similar_case_search",
            success=True,
            data=r.result,
            confidence=r.confidence,
            evidence=r.evidence,
        )
    except Exception as e:
        return ToolResult(
            tool_name="similar_case_search",
            success=False,
            error=str(e),
        )


# ═══════════════════════════════════════════════════════════════
# Tool 8: 对话追踪 (增强版 — LLM 槽位填充)
# ═══════════════════════════════════════════════════════════════


def dialogue_track(text: str, context: Dict = None) -> ToolResult:
    """对话状态追踪 —— LLM 驱动槽位填充"""
    if not context or "session_id" not in context:
        return ToolResult(
            tool_name="dialogue_track",
            success=False,
            error="缺少 session_id",
        )

    try:
        from agents.dialogue_tracker import DialogTracker
        tracker = DialogTracker()

        current_intent = context.get("intent", "")
        if current_intent:
            tracker.update_intent(context["session_id"], current_intent)

        r = tracker.process(text, context)
        return ToolResult(
            tool_name="dialogue_track",
            success=True,
            data=r.result,
            confidence=r.confidence,
            evidence=r.evidence,
        )
    except Exception as e:
        return ToolResult(
            tool_name="dialogue_track",
            success=False,
            error=str(e),
        )


# ═══════════════════════════════════════════════════════════════
# 工具注册表
# ═══════════════════════════════════════════════════════════════

ALL_TOOLS = [
    {
        "name": "intent_classify",
        "description": "识别用户消息的意图类别。用于理解用户想要什么：退款、投诉、咨询、报修、建议、纠纷调解、老人关怀、政策咨询、农技服务等。",
        "category": "analysis",
        "parameters": {
            "text": {"type": "string", "description": "用户消息文本"},
        },
        "required": ["text"],
        "trigger_keywords": ["退款", "投诉", "咨询", "报修", "建议", "纠纷", "老人", "政策", "农技", "紧急", "就业", "医疗", "环境", "教育"],
        "cost_estimate": "low",
        "fn": intent_classify,
    },
    {
        "name": "sentiment_analyze",
        "description": "分析用户消息的情感倾向：positive(正面)、neutral(中性)、negative(负面)、urgent(紧急/愤怒)。用于判断用户情绪状态。",
        "category": "analysis",
        "parameters": {
            "text": {"type": "string", "description": "用户消息文本"},
        },
        "required": ["text"],
        "trigger_keywords": ["生气", "满意", "感谢", "投诉", "愤怒", "差评", "太棒", "垃圾", "紧急", "危险"],
        "cost_estimate": "low",
        "fn": sentiment_analyze,
    },
    {
        "name": "entity_extract",
        "description": "从用户消息中提取关键实体信息：订单号、手机号、邮箱、地址、金额、日期、商品名、快递号等。",
        "category": "analysis",
        "parameters": {
            "text": {"type": "string", "description": "用户消息文本"},
        },
        "required": ["text"],
        "trigger_keywords": ["订单", "手机", "地址", "金额", "日期", "快递", "商品", "电话", "邮箱"],
        "cost_estimate": "low",
        "fn": entity_extract,
    },
    {
        "name": "urgency_assess",
        "description": "评估用户问题的紧急程度：low(普通)、medium(中等)、high(高)、critical(危急)。critical 可能涉及生命安全或重大舆情。",
        "category": "analysis",
        "parameters": {
            "text": {"type": "string", "description": "用户消息文本"},
        },
        "required": ["text"],
        "trigger_keywords": ["紧急", "危险", "安全", "12315", "投诉", "报警", "律师", "法庭", "死", "炸"],
        "cost_estimate": "low",
        "fn": urgency_assess,
    },
    {
        "name": "faq_retrieve",
        "description": "从 FAQ 知识库中检索与用户问题最匹配的问答对。返回最佳匹配及答案。",
        "category": "retrieval",
        "parameters": {
            "text": {"type": "string", "description": "用户问题文本"},
        },
        "required": ["text"],
        "trigger_keywords": ["怎么", "如何", "什么", "为什么", "能不能", "可以"],
        "cost_estimate": "low",
        "fn": faq_retrieve,
    },
    {
        "name": "policy_search",
        "description": "从政策文档库中检索与用户问题相关的政策条款。返回最匹配的政策内容和条款号。",
        "category": "retrieval",
        "parameters": {
            "text": {"type": "string", "description": "与政策相关的查询文本"},
        },
        "required": ["text"],
        "trigger_keywords": ["政策", "规定", "法规", "条例", "补贴", "低保", "养老", "医疗", "教育", "土地"],
        "cost_estimate": "low",
        "fn": policy_search,
    },
    {
        "name": "similar_case_search",
        "description": "从历史已解决工单库中检索与当前问题最相似的案例。返回案例的处理方式和结果。",
        "category": "retrieval",
        "parameters": {
            "text": {"type": "string", "description": "问题描述文本"},
        },
        "required": ["text"],
        "trigger_keywords": ["之前", "类似", "案例", "工单", "处理"],
        "cost_estimate": "low",
        "fn": similar_case_search,
    },
    {
        "name": "dialogue_track",
        "description": "追踪多轮对话状态，识别已收集的信息和缺失的槽位。用于生成追问和判断信息是否完整。",
        "category": "system",
        "parameters": {
            "text": {"type": "string", "description": "用户消息文本"},
        },
        "required": ["text"],
        "trigger_keywords": [],
        "cost_estimate": "low",
        "fn": dialogue_track,
    },
]
