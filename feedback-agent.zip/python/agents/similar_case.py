"""
Agent 7: 相似工单检索

使用 sentence-transformers + faiss 对历史已解决工单进行语义检索，
为 RAG 提供类似案例的实际处理经验。

初期使用内置样例工单，后续可接入真实工单数据库。
"""

import os
import json
import numpy as np

try:
    from . import BaseAgent, AgentResult
except ImportError:
    from agents import BaseAgent, AgentResult


# 内置样本工单（模拟历史已解决工单库）
SAMPLE_CASES = [
    {
        "case_id": "CASE-001",
        "title": "订单超30天退款申请",
        "description": "用户订单已超过30天，因商品质量问题申请退款。经核实商品存在质量缺陷，特批全额退款。",
        "category": "refund",
        "resolution": "全额退款",
        "tags": ["超期", "质量问题", "特批"],
    },
    {
        "case_id": "CASE-002",
        "title": "物流丢件赔偿处理",
        "description": "用户购买手机在运输途中丢失，快递公司确认丢件。商家重新发货并补偿50元优惠券。",
        "category": "inquiry",
        "resolution": "补发+补偿",
        "tags": ["物流", "丢件", "赔偿"],
    },
    {
        "case_id": "CASE-003",
        "title": "商品与描述严重不符",
        "description": "用户购买的衣服颜色和面料均与商品详情页描述不符，要求退一赔三。核实后按退一赔三处理。",
        "category": "complaint",
        "resolution": "退一赔三",
        "tags": ["描述不符", "退一赔三", "投诉"],
    },
    {
        "case_id": "CASE-004",
        "title": "大家电售后维修申请",
        "description": "用户购买冰箱使用两个月后出现制冷故障，在三包期内申请保修。安排师傅上门维修，费用由商家承担。",
        "category": "repair",
        "resolution": "免费维修",
        "tags": ["家电", "保修", "上门维修"],
    },
    {
        "case_id": "CASE-005",
        "title": "虚假发货投诉",
        "description": "商家上传虚假物流单号，实际未发货。核实属实，按商品金额10%赔偿（最高100元），并对商家进行警告处罚。",
        "category": "complaint",
        "resolution": "按政策赔偿+处罚商家",
        "tags": ["虚假发货", "赔偿", "处罚"],
    },
    {
        "case_id": "CASE-006",
        "title": "退货后商家拒收",
        "description": "用户申请无理由退货，退货商品完好但商家以「影响二次销售」为由拒收。平台介入后判定商家无理拒收，强制退款。",
        "category": "refund",
        "resolution": "平台介入强制退款",
        "tags": ["退货", "拒收", "平台介入"],
    },
    {
        "case_id": "CASE-007",
        "title": "客服态度恶劣投诉",
        "description": "用户投诉某客服在服务过程中言辞不当、态度恶劣。调取聊天记录核实后，对客服进行再培训，向用户致歉并补偿20元优惠券。",
        "category": "complaint",
        "resolution": "客服再培训+道歉+补偿",
        "tags": ["服务态度", "投诉", "补偿"],
    },
    {
        "case_id": "CASE-008",
        "title": "生鲜商品腐烂售后",
        "description": "用户签收车厘子后发现大量腐烂，在2小时内提交照片申请售后。核实后全额退款，无需退货。",
        "category": "refund",
        "resolution": "全额退款不退货",
        "tags": ["生鲜", "腐烂", "售后"],
    },
]


class SimilarCaseRetriever(BaseAgent):

    def __init__(self, model_name: str = None):
        super().__init__("SimilarCaseRetriever")
        self.cases = []
        self.embeddings = None
        self.index = None
        self.model = None

        if model_name is None:
            model_name = "paraphrase-multilingual-MiniLM-L12-v2"

        self._load_cases()
        self._load_model(model_name)
        self._build_index()

    def _load_cases(self):
        self.cases = SAMPLE_CASES

    def _load_model(self, model_name: str):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)

    def _build_index(self):
        import faiss
        texts = [c["description"] for c in self.cases]
        self.embeddings = self.model.encode(texts, normalize_embeddings=True)
        dim = self.embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dim)
        self.index.add(self.embeddings.astype(np.float32))

    def process(self, text: str, context: dict = None) -> AgentResult:
        if not self.cases:
            return self._low([], "历史工单库为空")

        query_emb = self.model.encode([text], normalize_embeddings=True).astype(np.float32)
        scores, indices = self.index.search(query_emb, k=3)

        results_list = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0 or idx >= len(self.cases):
                continue
            case = self.cases[idx]
            results_list.append({
                "case_id": case["case_id"],
                "title": case["title"],
                "description": case["description"],
                "category": case["category"],
                "resolution": case["resolution"],
                "tags": case.get("tags", []),
                "similarity": round(float(score), 4),
            })

        if not results_list:
            return self._low([], "未找到相似工单")

        best = results_list[0]

        # 相似工单的相似度一般低于 FAQ 匹配，放宽阈值
        confidence = min(best["similarity"] * 1.5, 1.0)

        evidence = [
            f"最相似工单: [{best['case_id']}] {best['title']} (相似度: {best['similarity']:.4f})",
            f"处理方式: {best['resolution']}",
        ]

        return AgentResult(
            agent_name=self.name,
            result={
                "matched": best,
                "candidates": results_list,
            },
            confidence=confidence,
            evidence=evidence,
            metadata={
                "total_cases": len(self.cases),
                "top_k": len(results_list),
            },
        )

    def add_case(self, case: dict):
        """添加新工单并重建索引"""
        case_id = f"CASE-{len(self.cases) + 1:03d}"
        case["case_id"] = case_id
        self.cases.append(case)
        self._build_index()


if __name__ == "__main__":
    retriever = SimilarCaseRetriever()
    test_queries = [
        "我买的手机在运输途中丢了，怎么处理？",
        "收到的衣服和图片完全不一样，我要投诉",
        "客服对我很凶，态度很差",
    ]
    for q in test_queries:
        r = retriever.process(q)
        best = r.result.get("matched", {}) if r.result else {}
        print(f"Q: {q}")
        print(f"  -> [{best.get('case_id', '-')}] {best.get('title', '-')} (score={r.confidence:.4f})")
        print(f"  -> 处理方式: {best.get('resolution', '-')}")
        print()
