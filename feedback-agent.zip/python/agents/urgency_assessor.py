"""
紧急度判定 Agent —— 符号层，零 LLM 依赖

方法：关键词触发 + 情感联动 + 客户等级权重
输出：urgency (low/medium/high/critical) + score + 置信度
"""
import json
import os
from typing import Dict, List, Optional

try:
    from . import BaseAgent, AgentResult
except ImportError:
    from agents import BaseAgent, AgentResult  # type: ignore


class UrgencyAssessor(BaseAgent):

    # 紧急关键词分级（不依赖情感词典，独立维护）
    CRITICAL_KEYWORDS = [
        "12315", "消费者协会", "工商局", "市场监管局", "律师函",
        "报警", "起诉", "法院", "安全隐患", "人身安全",
        "死亡", "爆炸", "着火", "漏电", "中毒", "烧伤",
        "媒体曝光", "上热搜", "记者", "电视台",
    ]
    HIGH_KEYWORDS = [
        "紧急", "急", "马上", "立刻", "尽快", "着急",
        "投诉", "举报", "曝光", "严重", "重大",
        "退款", "赔钱", "赔偿", "假一赔三", "假一赔十",
        "三天内", "24小时", "今天之内",
    ]
    MEDIUM_KEYWORDS = [
        "快点", "速度", "延迟", "拖延", "催促",
        "不好使", "不能用", "坏了", "一直", "反复",
        "第三次", "第N次", "好几天",
    ]

    def __init__(self, dict_path: Optional[str] = None):
        super().__init__("urgency_assessor")
        # 加载情感词典获取 intensifiers
        if dict_path is None:
            dict_path = os.path.join(
                os.path.dirname(__file__), "..", "knowledge", "sentiment_dict.json"
            )
        with open(dict_path, "r", encoding="utf-8") as f:
            self.sent_dict = json.load(f)

    def process(self, text: str, context: Optional[Dict] = None) -> AgentResult:
        evidence: List[str] = []
        score = 0.0

        # 1. 关键词匹配
        critical_hits = sum(1 for kw in self.CRITICAL_KEYWORDS if kw in text)
        high_hits = sum(1 for kw in self.HIGH_KEYWORDS if kw in text)
        medium_hits = sum(1 for kw in self.MEDIUM_KEYWORDS if kw in text)

        if critical_hits > 0:
            score = 0.9 + critical_hits * 0.05
            evidence.append(f"危急关键词: {critical_hits} 个")
        elif high_hits > 0:
            score = 0.6 + high_hits * 0.1
            evidence.append(f"高紧急关键词: {high_hits} 个")
        elif medium_hits > 0:
            score = 0.35 + medium_hits * 0.1
            evidence.append(f"中紧急关键词: {medium_hits} 个")

        # 2. 强化词加成
        intensifier_count = sum(
            1 for w in self.sent_dict.get("intensifiers", []) if w in text
        )
        score += intensifier_count * 0.04
        if intensifier_count:
            evidence.append(f"强化词: +{intensifier_count * 0.04:.2f}")

        # 3. 外部传入的情感信号（来自 SentimentAnalyzer）
        if context and "sentiment" in context:
            sentiment = context["sentiment"]
            if sentiment == "urgent":
                score += 0.3
                evidence.append("情感联动: urgent +0.3")
            elif sentiment == "negative":
                score += max(0.0, context.get("sentiment_intensity", 0) * 0.15)
                evidence.append(f"情感联动: negative +{context.get('sentiment_intensity', 0) * 0.15:.2f}")

        # 4. 客户等级（外部传入）
        if context and "vip_level" in context:
            vip = context["vip_level"]
            if vip >= 3:
                score += 0.1
                evidence.append(f"VIP{vip}加成: +0.1")

        # 5. 历史工单数（外部传入，高频用户可能优先处理）
        if context and "history_count" in context:
            history = context["history_count"]
            if history > 10:
                score += 0.05
                evidence.append(f"高频用户(>{history}): +0.05")

        score = min(1.0, score)

        # 判定级别
        if score >= 0.8:
            urgency = "critical"
            confidence = 0.9
        elif score >= 0.5:
            urgency = "high"
            confidence = 0.8
        elif score >= 0.25:
            urgency = "medium"
            confidence = 0.7
        else:
            urgency = "low"
            confidence = 0.85

        return self._ok(
            result={
                "urgency": urgency,
                "score": round(score, 2),
            },
            confidence=confidence,
            evidence=evidence if evidence else ["未命中紧急信号 — 默认低优先级"],
        )


if __name__ == "__main__":
    agent = UrgencyAssessor()
    tests = [
        ("这个产品有安全隐患，可能会爆炸！我要向12315投诉！", {"vip_level": 2}),
        ("我的退款什么时候处理？已经等了三天了", {}),
        ("订单 ORD-1234 一直没到，催一下", {}),
        ("路过看看，随便问问", {}),
        ("非常着急！！！马上给我处理！！！否则我要找律师了", {"vip_level": 3}),
    ]
    for text, ctx in tests:
        r = agent.process(text, context=ctx)
        print(f"IN:  {text}")
        print(f"OUT: {r.result} conf={r.confidence}")
        print(f"EVD: {r.evidence}")
        print()
