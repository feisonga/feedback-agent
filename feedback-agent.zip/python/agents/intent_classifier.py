"""
意图分类 Agent —— 符号层，零 LLM 依赖

方法：正则模式匹配 + 关键词权重投票
输出：意图类别 + 置信度 + 命中证据
"""
import re
import yaml
import os
from typing import Dict, List, Optional, Tuple
try:
    from . import BaseAgent, AgentResult
except ImportError:
    from agents import BaseAgent, AgentResult  # type: ignore


class IntentClassifier(BaseAgent):

    def __init__(self, patterns_path: Optional[str] = None):
        super().__init__("intent_classifier")
        if patterns_path is None:
            patterns_path = os.path.join(
                os.path.dirname(__file__), "..", "knowledge", "intent_patterns.yaml"
            )
        with open(patterns_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)

        self.intents: Dict = config["intents"]
        self.priority: Dict[str, int] = config["priority"]

    def process(self, text: str, context: Optional[Dict] = None) -> AgentResult:
        scores: Dict[str, float] = {}
        evidence: List[str] = []

        for intent_name, intent_cfg in self.intents.items():
            if intent_name == "other":
                continue

            pattern_hits = 0
            for pat in intent_cfg.get("patterns", []):
                if re.search(pat, text, re.IGNORECASE):
                    pattern_hits += 1

            keyword_hits = 0
            for kw in intent_cfg.get("keywords", []):
                if kw in text:
                    keyword_hits += 1

            weight = intent_cfg.get("weight", 1)
            raw_score = pattern_hits * weight * 2 + keyword_hits * weight
            scores[intent_name] = raw_score

            if pattern_hits > 0:
                evidence.append(
                    f"{intent_name}: {pattern_hits} pattern(s), {keyword_hits} keyword(s) → raw={raw_score}"
                )

        if not scores:
            return self._ok(
            {"intent": "other", "label": "其它", "slots": {}, "scores": {}},
            0.3, ["未命中任何意图规则"],
        )

        # 归一化
        max_raw = max(scores.values()) if scores else 1
        if max_raw == 0:
            return self._ok(
                {"intent": "other", "label": "其它", "slots": {}, "scores": {}},
                0.3, ["所有意图得分均为0"],
            )

        normalized = {k: v / max_raw for k, v in scores.items()}

        # 找最高分意图
        best_intent = max(normalized, key=lambda k: normalized[k])
        best_score = normalized[best_intent]

        # 歧义消解：如果存在多个高分意图，按优先级打破平局
        close_candidates = [
            k for k, v in normalized.items()
            if v >= best_score - 0.15 and k != best_intent
        ]
        if close_candidates and best_score < 0.95:
            for candidate in close_candidates:
                if self.priority.get(candidate, 0) > self.priority.get(best_intent, 0):
                    evidence.append(
                        f"歧义消解: {best_intent}({best_score:.2f}) → {candidate}"
                        f"(优先级 {self.priority[candidate]} > {self.priority[best_intent]})"
                    )
                    best_intent = candidate
                    best_score = normalized[candidate]

        # 置信度校准
        if best_score >= 0.85:
            confidence = min(0.95, best_score)
        elif best_score >= 0.5:
            confidence = 0.6
        else:
            confidence = 0.35
            best_intent = "other"

        return self._ok(
            result={
                "intent": best_intent,
                "label": self.intents.get(best_intent, {}).get("label", best_intent),
                "slots": self.intents.get(best_intent, {}).get("slots", {}),
                "scores": {k: round(v, 3) for k, v in sorted(normalized.items(), key=lambda x: -x[1])[:3]},
            },
            confidence=confidence,
            evidence=evidence,
        )


if __name__ == "__main__":
    agent = IntentClassifier()
    tests = [
        "我要退款，订单 ORD-12345 买的东西坏了",
        "你们这个质量也太差了，我要投诉",
        "请问这个商品的发货时间是什么时候",
        "我的手机屏幕碎了，怎么报修",
        "建议你们增加一个夜间客服通道",
        "今天天气真好",  # → other
    ]
    for t in tests:
        r = agent.process(t)
        print(f"IN:  {t}")
        print(f"OUT: {r.result['intent']}({r.result['label']}) conf={r.confidence}")
        print(f"EVD: {r.evidence}")
        print()
