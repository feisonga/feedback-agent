"""
Agent 基类 & 统一输出格式

所有 Agent 必须返回 AgentResult，确保调度中心可以统一处理。
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from abc import ABC, abstractmethod


@dataclass
class AgentResult:
    """Agent 统一输出格式"""
    agent_name: str              # Agent 标识
    result: Any                  # 核心结果（str / dict / list）
    confidence: float            # 置信度 [0.0, 1.0]
    evidence: List[str] = field(default_factory=list)  # 决策依据
    metadata: Dict = field(default_factory=dict)       # 额外信息

    def is_high_confidence(self, threshold: float = 0.9) -> bool:
        return self.confidence >= threshold

    def is_low_confidence(self, threshold: float = 0.5) -> bool:
        return self.confidence < threshold


class BaseAgent(ABC):
    """符号层 Agent 基类"""

    def __init__(self, name: str):
        self.name = name

    @abstractmethod
    def process(self, text: str, context: Optional[Dict] = None) -> AgentResult:
        """处理输入文本，返回结构化结果"""
        ...

    def _ok(self, result: Any, confidence: float = 1.0,
            evidence: Optional[List[str]] = None, metadata: Optional[Dict] = None) -> AgentResult:
        """快捷构造高置信度结果"""
        return AgentResult(
            agent_name=self.name,
            result=result,
            confidence=confidence,
            evidence=evidence or [],
            metadata=metadata or {},
        )

    def _low(self, result: Any, reason: str = "",
             metadata: Optional[Dict] = None) -> AgentResult:
        """快捷构造低置信度结果"""
        return AgentResult(
            agent_name=self.name,
            result=result,
            confidence=0.3,
            evidence=[f"低置信度: {reason}"] if reason else [],
            metadata=metadata or {},
        )
