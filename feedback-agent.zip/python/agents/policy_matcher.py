"""
Agent 5: 政策匹配

使用 Whoosh BM25 全文检索引擎对政策文档建索引，
根据用户问题检索相关政策条款，为 RAG 提供权威文档片段。
建索引前用 jieba 对中文进行预分词，查询时同样分词后搜索。
"""

import os
import re

try:
    from . import BaseAgent, AgentResult
except ImportError:
    from agents import BaseAgent, AgentResult


class PolicyMatcher(BaseAgent):

    def __init__(self, docs_dir: str = None, index_dir: str = None):
        super().__init__("PolicyMatcher")

        if docs_dir is None:
            docs_dir = os.path.join(os.path.dirname(__file__), "..", "knowledge", "policy_docs")
        self.docs_dir = os.path.normpath(docs_dir)

        if index_dir is None:
            index_dir = os.path.join(os.path.dirname(__file__), "..", "knowledge", "policy_index")
        self.index_dir = os.path.normpath(index_dir)

        self.doc_articles = {}
        import jieba
        self._load_documents()
        self._build_index()

    def _load_documents(self):
        self.doc_articles = {}
        for fname in sorted(os.listdir(self.docs_dir)):
            if not fname.endswith(".txt"):
                continue
            fpath = os.path.join(self.docs_dir, fname)
            with open(fpath, "r", encoding="utf-8") as f:
                text = f.read()
            articles = self._split_articles(text)
            for art_id, art_title, art_content in articles:
                key = f"{fname}::{art_id}"
                self.doc_articles[key] = {
                    "doc_name": fname.replace(".txt", ""),
                    "article_id": art_id,
                    "title": art_title,
                    "content": art_content.strip(),
                }

    def _split_articles(self, text: str):
        parts = re.split(r'(第[一二三四五六七八九十百千]+条\s*[^\n]*)', text)
        articles = []
        for i in range(1, len(parts), 2):
            art_title = parts[i].strip() if i < len(parts) else ""
            art_content = parts[i + 1].strip() if i + 1 < len(parts) else ""
            art_id = self._parse_article_number(art_title)
            articles.append((art_id, art_title, art_content))
        return articles

    def _parse_article_number(self, title: str):
        m = re.match(r'第([一二三四五六七八九十百千]+)条', title)
        if m:
            return m.group(1)
        return title

    def _tokenize(self, text: str) -> str:
        """用 jieba 分词，返回空格分隔的字符串"""
        import jieba
        tokens = jieba.cut(text)
        return " ".join(t for t in tokens if t.strip())

    def _build_index(self):
        from whoosh.index import create_in
        from whoosh.fields import Schema, TEXT, ID

        os.makedirs(self.index_dir, exist_ok=True)

        from whoosh.index import exists_in
        if exists_in(self.index_dir):
            return

        schema = Schema(
            doc_key=ID(stored=True, unique=True),
            doc_name=TEXT(stored=True),
            article_id=TEXT(stored=True),
            title=TEXT(stored=True),
            content=TEXT(stored=True),
        )

        ix = create_in(self.index_dir, schema)
        writer = ix.writer()
        for key, art in self.doc_articles.items():
            writer.add_document(
                doc_key=key,
                doc_name=art["doc_name"],
                article_id=art["article_id"],
                title=self._tokenize(art["title"]),
                content=self._tokenize(art["content"]),
            )
        writer.commit()

    def process(self, text: str, context: dict = None) -> AgentResult:
        from whoosh.index import open_dir
        from whoosh.qparser import QueryParser

        from whoosh.index import exists_in
        if not exists_in(self.index_dir):
            return self._low([], "政策索引不存在")

        query_tokens = self._tokenize(text)
        if not query_tokens.strip():
            return self._low([], "查询分词后为空")

        ix = open_dir(self.index_dir)
        results_list = []

        with ix.searcher() as searcher:
            from whoosh.qparser import QueryParser, OrGroup
            parser = QueryParser("content", ix.schema, group=OrGroup)
            q = parser.parse(query_tokens)
            hits = searcher.search(q, limit=5)

            max_score = hits.score(0) if hits and len(hits) > 0 else 1.0

            for hit in hits:
                score = hit.score / max_score if max_score > 0 else 0
                results_list.append({
                    "doc_name": hit["doc_name"],
                    "article_id": hit["article_id"],
                    "title": hit["title"],
                    "content": hit["content"][:300],
                    "score": round(score, 4),
                })

        if not results_list:
            return self._low([], "未找到匹配的政策条款")

        best = results_list[0]
        confidence = min(best["score"] * 1.2, 1.0)

        evidence = [
            f"政策匹配: [{best['doc_name']}] {best['title']} (BM25得分: {best['score']:.4f})",
        ]
        if len(results_list) > 1:
            evidence.append(f"共检索到 {len(results_list)} 条相关政策条款")

        return AgentResult(
            agent_name=self.name,
            result={
                "matched": best,
                "candidates": results_list,
            },
            confidence=confidence,
            evidence=evidence,
            metadata={"total_candidates": len(results_list)},
        )


if __name__ == "__main__":
    matcher = PolicyMatcher()
    test_queries = [
        "退款多久到账？",
        "怎么投诉商家？",
        "人工客服工作时间是几点？",
        "假冒伪劣商品怎么赔偿？",
    ]
    for q in test_queries:
        r = matcher.process(q)
        best = r.result.get("matched", {}) if r.result else {}
        print(f"Q: {q}")
        print(f"  -> [{best.get('doc_name', '-')}] {best.get('title', '-')} (confidence={r.confidence:.4f})")
        print(f"  -> {best.get('content', '')[:120]}...")
        print()
