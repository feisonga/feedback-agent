"""
实体抽取 Agent —— 符号层，零 LLM 依赖

方法：jieba 分词 + 正则命名实体识别
输出：实体列表 + 置信度 + 命中证据
"""
import re
import os
from typing import Dict, List, Optional

import jieba
import yaml

try:
    from . import BaseAgent, AgentResult
except ImportError:
    from agents import BaseAgent, AgentResult  # type: ignore


class EntityExtractor(BaseAgent):

    def __init__(self, patterns_path: Optional[str] = None):
        super().__init__("entity_extractor")
        if patterns_path is None:
            patterns_path = os.path.join(
                os.path.dirname(__file__), "..", "knowledge", "entity_patterns.yaml"
            )
        with open(patterns_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)
        self.entity_configs = config["entities"]
        # 按优先级排序
        self.entity_list = sorted(
            self.entity_configs.items(),
            key=lambda kv: kv[1]["priority"],
            reverse=True,
        )

    def _extract_entities(self, text: str) -> tuple:
        """
        执行实体抽取。
        返回 (entities_dict, evidence_list)
        """
        entities: Dict[str, List[str]] = {}
        evidence: List[str] = []
        matched_spans: List[Tuple[int, int]] = []  # 已匹配区间，避免重叠

        for entity_type, cfg in self.entity_list:
            entities[entity_type] = []
            for pattern in cfg["patterns"]:
                for match in re.finditer(pattern, text):
                    start, end = match.span()
                    # 检查是否与已匹配区间重叠
                    overlap = any(
                        not (end <= ms or start >= me)
                        for ms, me in matched_spans
                    )
                    if overlap:
                        continue

                    value = match.group(1) if match.groups() else match.group(0)
                    value = value.strip()
                    if value:
                        entities[entity_type].append(value)
                        matched_spans.append((start, end))

            if entities[entity_type]:
                # 去重保序
                seen = set()
                unique = []
                for v in entities[entity_type]:
                    if v not in seen:
                        seen.add(v)
                        unique.append(v)
                entities[entity_type] = unique
                evidence.append(
                    f"{cfg['label']}({entity_type}): {unique}"
                )

        return entities, evidence

    def _extract_product(self, text: str, entities: Dict) -> Dict:
        """
        用 jieba 提取可能的商品名。
        过滤数字、量词、虚词、已识别实体值。
        """
        # 收集所有已识别实体值，避免作为商品名重复
        known_values = set()
        for entity_list in entities.values():
            for v in entity_list:
                known_values.add(v.lower())

        stop_words = {
            "这个", "那个", "哪个", "什么", "怎么", "东西", "商品",
            "订单", "退款", "退货", "我要", "需要", "可以", "能不能",
            "我的", "你的", "他的", "我们", "你们", "他们",
            "一个", "一下", "一些", "有点", "已经", "还是",
            "非常", "因为", "所以", "但是", "不过", "然后",
            "请", "帮", "给", "把", "被", "让", "叫",
            "是", "的", "了", "着", "过", "在", "有",
            "吗", "吧", "呢", "啊", "呀", "哦", "嗯",
            "这", "那", "和", "与", "或", "且", "就", "才",
        }

        words = list(jieba.cut(text))
        candidates = []
        for w in words:
            w_clean = w.strip()
            if w_clean.lower() in known_values:
                continue
            if w_clean in stop_words:
                continue
            if len(w_clean) < 2:
                continue
            # 排除纯数字、纯标点、纯英文单字母
            if re.match(r'^[\d\.\-,，。！？、：；""''（）\\s]+$', w_clean):
                continue
            if re.match(r'^[a-zA-Z]$', w_clean):
                continue
            # 只保留中文字符或中英混合的"看起来像商品名"的
            if re.search(r'[一-鿿]', w_clean) or re.match(r'^[A-Z][a-z]+$', w_clean):
                candidates.append(w_clean)

        # 去重
        seen = set()
        unique = []
        for c in candidates:
            if c not in seen:
                seen.add(c)
                unique.append(c)
        return unique[:5]  # 最多 5 个候选

    def process(self, text: str, context: Optional[Dict] = None) -> AgentResult:
        entities, evidence = self._extract_entities(text)

        # 补充 jieba 提取商品名
        if "product_name" not in entities or not entities["product_name"]:
            product_candidates = self._extract_product(text, entities)
            if product_candidates:
                entities["product_name"] = product_candidates
                evidence.append(f"商品名(jieba): {product_candidates}")

        # 统计
        total_entities = sum(len(v) for v in entities.values() if v)
        # 置信度 = 找到的实体类型数 / 可能的类型数，至少 0.5
        non_empty = sum(1 for v in entities.values() if v)
        confidence = min(0.95, max(0.3, non_empty / max(len(entities), 1)))

        return self._ok(
            result={
                "entities": entities,
                "total": total_entities,
            },
            confidence=confidence,
            evidence=evidence if evidence else ["未提取到实体"],
        )


if __name__ == "__main__":
    agent = EntityExtractor()
    tests = [
        "我的订单 ORD-12345 还没收到，手机号 13812345678",
        "2024年3月15日购买的，金额 299.00 元，京东快递 JD0012345678",
        "我的手机屏幕碎了，需要维修",
        "请发到邮箱 test@example.com，地址是北京市朝阳区某某路123号",
    ]
    for t in tests:
        r = agent.process(t)
        print(f"IN:  {t}")
        print(f"OUT: {r.result}")
        print(f"CONF: {r.confidence}")
        print()
