"""
情感判定 Agent —— 混合层（规则为主，不调 LLM）

方法：情感词典匹配 + 标点/大写规则 + 否定词处理
输出：sentiment (positive/neutral/negative/urgent) + intensity + 置信度
"""
import json
import os
import re
from typing import Dict, List, Optional

try:
    from . import BaseAgent, AgentResult
except ImportError:
    from agents import BaseAgent, AgentResult  # type: ignore


class SentimentAnalyzer(BaseAgent):

    def __init__(self, dict_path: Optional[str] = None):
        super().__init__("sentiment_analyzer")
        if dict_path is None:
            dict_path = os.path.join(
                os.path.dirname(__file__), "..", "knowledge", "sentiment_dict.json"
            )
        with open(dict_path, "r", encoding="utf-8") as f:
            self.dict = json.load(f)

    def _count_hits(self, text: str, word_list: List[str]) -> int:
        """统计词表中在文本中的命中数"""
        return sum(1 for w in word_list if w in text)

    def _check_intensifiers(self, text: str) -> int:
        """统计强化词命中"""
        return sum(1 for w in self.dict["intensifiers"] if w in text)

    def _check_punctuation_boost(self, text: str) -> float:
        """标点/大写增强信号"""
        boost = 0.0
        exclam = len(re.findall(self.dict["exclamation_pattern"], text))
        if exclam >= self.dict.get("exclamation_threshold", 3):
            boost += 0.15
        elif exclam >= 1:
            boost += 0.05

        question = len(re.findall(self.dict["question_marks_pattern"], text))
        if question >= 3:
            boost += 0.08

        # 中文字符全大写检测不适用，检测是否全为半角字符
        alpha_chars = re.findall(r'[a-zA-Z]+', text)
        if alpha_chars:
            caps_ratio = sum(1 for c in ''.join(alpha_chars) if c.isupper()) / max(len(''.join(alpha_chars)), 1)
            if caps_ratio >= self.dict.get("caps_ratio_threshold", 0.5):
                boost += 0.1

        return min(0.3, boost)

    def process(self, text: str, context: Optional[Dict] = None) -> AgentResult:
        evidence: List[str] = []

        # 1. 紧急词检测（最高优先级）
        urgent_hits = self._count_hits(text, self.dict["urgent"])
        if urgent_hits > 0:
            return self._ok(
                result={"sentiment": "urgent", "intensity": min(1.0, 0.7 + urgent_hits * 0.1)},
                confidence=0.9,
                evidence=[f"紧急词命中 {urgent_hits} 个"],
            )

        # 2. 否定词检测（排除复合词如"非常""不错"）
        negation_text = text
        for compound in self.dict.get("negation_exclude_compounds", []):
            negation_text = negation_text.replace(compound, "")
        negation_hits = self._count_hits(negation_text, self.dict["negation_words"])
        has_negation = negation_hits > 0

        # 3. 正/负向词命中统计
        neg_strong = self._count_hits(text, self.dict["negative"]["strong"])
        neg_moderate = self._count_hits(text, self.dict["negative"]["moderate"])
        neg_mild = self._count_hits(text, self.dict["negative"]["mild"])
        pos_strong = self._count_hits(text, self.dict["positive"]["strong"])
        pos_moderate = self._count_hits(text, self.dict["positive"]["moderate"])
        pos_mild = self._count_hits(text, self.dict["positive"]["mild"])

        # 加权得分
        neg_score = neg_strong * 3 + neg_moderate * 2 + neg_mild * 1
        pos_score = pos_strong * 3 + pos_moderate * 2 + pos_mild * 1

        # 强化词加成
        intensifier_count = self._check_intensifiers(text)
        punctuation_boost = self._check_punctuation_boost(text)

        # 否定词翻转（仅在有正向词且被否定时）
        if has_negation and pos_score > 0 and neg_score == 0:
            neg_score = pos_score * 0.5
            pos_score = 0
            evidence.append("否定词翻转: 正向→负向")

        boost = intensifier_count * 0.05 + punctuation_boost
        neg_score += boost
        pos_score += boost

        # 4. 判定
        evidence.append(
            f"neg(s={neg_strong},m={neg_moderate},w={neg_mild})="
            f"{neg_score:.1f} pos(s={pos_strong},m={pos_moderate},w={pos_mild})="
            f"{pos_score:.1f} boost={boost:.2f}"
        )

        if neg_score == 0 and pos_score == 0:
            return self._ok(
                result={"sentiment": "neutral", "intensity": 0.0},
                confidence=0.85,
                evidence=evidence + ["无情感信号"],
            )

        if neg_score > pos_score + 1.0:
            sentiment = "negative"
            intensity = min(1.0, neg_score / 10)
            confidence = min(0.95, 0.7 + neg_score * 0.05)
        elif pos_score > neg_score + 1.0:
            sentiment = "positive"
            intensity = min(1.0, pos_score / 10)
            confidence = min(0.95, 0.7 + pos_score * 0.05)
        else:
            sentiment = "neutral"
            intensity = 0.1
            confidence = 0.6

        return self._ok(
            result={"sentiment": sentiment, "intensity": round(intensity, 2)},
            confidence=round(confidence, 2),
            evidence=evidence,
        )


if __name__ == "__main__":
    agent = SentimentAnalyzer()
    tests = [
        "太棒了！！！非常满意这个产品，超级好用，强烈推荐！！！",
        "太烂了，质量堪忧，简直就是垃圾，我要投诉到12315！气死我了！",
        "东西还行吧，就是发货有点慢",
        "我的订单一直没收到，给个说法！！！",
        "非常危险！这个产品有安全隐患，必须马上处理！！！",
    ]
    for t in tests:
        r = agent.process(t)
        print(f"IN:  {t}")
        print(f"OUT: {r.result} conf={r.confidence}")
        print(f"EVD: {r.evidence}")
        print()
