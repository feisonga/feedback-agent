"""
人称转换器 —— 符号主义实现，零 LLM 依赖。

用途：
  1. user_to_system：将用户原话转为系统视角（我→您、我的→您的）
     → 用于实体抽取前归一化、对话状态存储
  2. system_to_user：将系统回复中的"我"转为用户视角（保持尊敬格式）
     → 用于 Response Builder 生成模板后的润色

设计原则：
  - 最长匹配优先，避免"我的"被"我"吞噬
  - 中英文独立规则表，互不干扰
  - 所有规则可追溯，每个替换记录 evidence
"""

import re
from typing import List, Tuple, Dict, Optional

# ============================================================
# 中文人称转换规则
# ============================================================

# 用户→系统视角：把用户口中的"我/我的/我们"改成"您/您的/你们"
CN_USER_TO_SYSTEM: List[Tuple[str, str]] = [
    # 长短语优先（按长度降序排列）
    ("我们自己", "你们自己"),
    ("我们的",   "你们的"),
    ("咱们",     "你们"),
    ("我们",     "你们"),
    ("我本人",   "您本人"),
    ("我自己",   "您自己"),
    ("我的",     "您的"),
    ("本人",     "您"),
    ("我",       "您"),
    # 第二人称反查：用户偶尔用"你"指代客服，转为"我"
    ("你们的",   "我们的"),
    ("你自己",   "我自己"),
    ("你的",     "我的"),
    ("你",       "我"),
    # 敬称保留
    ("您的",     "我的"),
    ("您自己",   "我自己"),
    ("您",       "我"),
]

# 系统→用户视角：把系统回复中的"我/我们"保持为"我/我们"（客服身份）
# 实际上客服回复模板已经是第一人称，此函数主要用于：
#   - 将内部存储的 Observation 数据转换为友好回复
#   - 把"您的订单"等内部格式转为"您的订单"（保持）
CN_SYSTEM_TO_USER: List[Tuple[str, str]] = [
    # 系统内部可能存"我"指代客服，对外保持即可
    # 此方向主要是确保"您"不被误改
    ("我们系统", "我们"),
    ("我们客服", "我们"),
    # 保持用户侧的"您"
    ("你",       "您"),   # 系统内部如果用了"你"，对外统一升级为"您"
    ("你的",     "您的"),
    ("你们",     "你们"),  # 保持不变
]

# ============================================================
# 英文人称转换规则
# ============================================================

EN_SWAP: Dict[str, str] = {
    "i": "you", "you": "i", "me": "you",
    "my": "your", "your": "my", "mine": "yours",
    "yours": "mine", "myself": "yourself",
    "yourself": "myself", "am": "are", "are": "am",
    "was": "were", "were": "was",
    "i'd": "you would", "i've": "you have",
    "i'll": "you will", "we": "you",
    "us": "you", "our": "your", "ours": "yours",
    "ourselves": "yourselves",
}

# 英文缩写展开（确保 split 后一致）
EN_CONTRACTIONS: Dict[str, str] = {
    "i'm":    "i am",
    "you're": "you are",
    "i'd":    "i would",
    "i've":   "i have",
    "i'll":   "i will",
    "we're":  "we are",
    "we've":  "we have",
    "we'll":  "we will",
    "they're": "they are",
    "it's":   "it is",
}


def _swap_with_placeholders(rules: List[Tuple[str, str]], text: str) -> Tuple[str, List[str]]:
    """
    使用占位符隔离技术替换文本中的人称，防止循环替换。

    原理：
      "我的" → "__PSWAP_0__" → 最终 "您的"
      "__PSWAP_0__" 不会被后续规则再次匹配，避免 "您的" 又被改回 "我的"。

    返回 (替换后文本, 触发的规则记录列表)。
    """
    evidence: List[str] = []
    placeholders: List[Tuple[str, str]] = []  # [(placeholder, final_value)]

    result = text
    for i, (pattern, replacement) in enumerate(rules):
        if pattern in result:
            placeholder = f"__PSWAP_{i}__"
            result = result.replace(pattern, placeholder)
            placeholders.append((placeholder, replacement))
            evidence.append(f"{pattern}→{replacement}")

    # 阶段二：占位符 → 最终值
    for placeholder, final_value in placeholders:
        result = result.replace(placeholder, final_value)

    return result, evidence


def _swap_english_words(phrase: str) -> str:
    """对英文短语逐词进行人称转换（兼容 ELIZA 风格）。"""
    # 先展开缩写
    words_lower = phrase.lower()
    for contracted, expanded in EN_CONTRACTIONS.items():
        words_lower = words_lower.replace(contracted, expanded)

    words = words_lower.split()
    swapped = [EN_SWAP.get(w, w) for w in words]
    return " ".join(swapped)


def user_to_system(text: str) -> Dict:
    """
    将用户原话转换为系统处理视角。

    中文：我→您、我的→您的、我们→你们
    英文：I→you、my→your、we→you

    返回 {text, evidence}
    """
    evidence: List[str] = []
    result = text

    # 1. 处理中文部分（包含中文字符时触发）
    if re.search(r'[一-鿿]', result):
        result, cn_ev = _swap_with_placeholders(CN_USER_TO_SYSTEM, result)
        evidence.extend(cn_ev)

    # 2. 处理英文部分（包含英文字母时触发）
    if re.search(r'[a-zA-Z]', result):
        # 提取英文片段进行转换
        def _replace_en(match):
            return _swap_english_words(match.group(0))
        old_en_parts = re.findall(r'[a-zA-Z\']+', text)
        result = re.sub(r'[a-zA-Z\']+', _replace_en, result)
        if old_en_parts:
            evidence.append(f"EN:{';'.join(old_en_parts)}→swapped")

    return {
        "text": result,
        "evidence": evidence if evidence else ["no change"],
        "direction": "user_to_system",
    }


def system_to_user(text: str) -> Dict:
    """
    将系统内部回复转换为面向用户的友好表达。

    中文：确保用"您"而非"你"，保持客服第一人称"我"
    英文：I→you（保持一致）

    返回 {text, evidence}
    """
    evidence: List[str] = []
    result = text

    if re.search(r'[一-鿿]', result):
        result, cn_ev = _swap_with_placeholders(CN_SYSTEM_TO_USER, result)
        evidence.extend(cn_ev)

    if re.search(r'[a-zA-Z]', result):
        def _replace_en(match):
            return _swap_english_words(match.group(0))
        result = re.sub(r'[a-zA-Z\']+', _replace_en, result)
        evidence.append("EN swapped")

    return {
        "text": result,
        "evidence": evidence if evidence else ["no change"],
        "direction": "system_to_user",
    }


# ============================================================
# 自测
# ============================================================
if __name__ == "__main__":
    cases = [
        # === 中文：用户→系统 ===
        ("我的订单一直没有收到", "user_to_system"),
        ("我要退款，我买的东西坏了", "user_to_system"),
        ("我们自己检查过了，不是我弄坏的", "user_to_system"),
        ("你之前说过可以退的", "user_to_system"),
        ("你们的客服态度很差", "user_to_system"),
        ("我本人的账号被锁了", "user_to_system"),
        ("咱们之前商量好的方案呢", "user_to_system"),
        # === 中文：系统→用户 ===
        ("我已经帮您查询了订单状态", "system_to_user"),
        ("你的问题我们已经收到", "system_to_user"),
        # === 英文 ===
        ("I need to return my order", "user_to_system"),
        ("You told me I could refund", "user_to_system"),
        ("I've been waiting for my package", "user_to_system"),
    ]

    for text, direction in cases:
        if direction == "user_to_system":
            r = user_to_system(text)
        else:
            r = system_to_user(text)
        print(f"[{direction}]")
        print(f"  IN:  {text}")
        print(f"  OUT: {r['text']}")
        print(f"  EVD: {r['evidence']}")
        print()
