"""
用户操作函数：获取用户画像等
"""

# 模拟用户数据库
_MOCK_CUSTOMERS = {
    "VIP-001": {"name": "张先生", "level": "钻石会员", "points": 15800, "history_count": 3},
    "VIP-002": {"name": "李女士", "level": "普通会员", "points": 1200, "history_count": 1},
}


def get_customer_profile(user_id: str = "") -> str:
    """获取用户画像（VIP 等级、历史工单数等）"""
    if not user_id:
        return "未提供用户 ID，无法查询用户画像。"
    profile = _MOCK_CUSTOMERS.get(user_id)
    if not profile:
        return f"未找到用户 {user_id} 的信息。"
    return (f"用户：{profile['name']}，等级「{profile['level']}」，"
            f"积分 {profile['points']}，历史工单 {profile['history_count']} 次。")
