"""
订单操作函数：查询订单、退款资格检查、取消订单等
"""

# 模拟订单数据库
_MOCK_ORDERS = {
    "ORD-8848": {"status": "已发货", "logistics": "顺丰 SF12345", "product": "蓝牙耳机", "amount": 299.0},
    "ORD-1234": {"status": "已签收", "logistics": "圆通 YT98765", "product": "羽绒服", "amount": 599.0},
    "ORD-5678": {"status": "待发货", "logistics": "", "product": "手机壳", "amount": 39.0},
    "ORD-9999": {"status": "已完成", "logistics": "中通 ZT45678", "product": "机械键盘", "amount": 899.0},
}


def query_order(order_id: str) -> str:
    """查询订单状态和物流信息"""
    order = _MOCK_ORDERS.get(order_id)
    if not order:
        return f"未找到订单 {order_id}，请核实订单号是否正确。"
    if order["logistics"]:
        return f"订单 {order_id}：{order['product']}，状态「{order['status']}」，物流「{order['logistics']}」。"
    return f"订单 {order_id}：{order['product']}，状态「{order['status']}」，暂未发货。"


def query_refund_eligibility(order_id: str) -> str:
    """检查订单是否满足退款条件"""
    order = _MOCK_ORDERS.get(order_id)
    if not order:
        return f"未找到订单 {order_id}。"
    if order["status"] in ("已发货", "已签收", "已完成"):
        return f"订单 {order_id}（{order['product']}）支持退款申请。请在订单详情页发起退款，退回商品应保持完好。"
    if order["status"] == "待发货":
        return f"订单 {order_id}（{order['product']}）尚未发货，可在「我的订单」中直接取消订单。"
    return f"订单 {order_id} 状态为「{order['status']}」，请联系人工客服处理。"


def check_inventory(product_name: str) -> str:
    """查询商品库存"""
    # 模拟库存查询
    mock_inventory = {
        "蓝牙耳机": "有货，库存充足",
        "羽绒服": "有货，库存充足",
        "手机壳": "有货，剩余 15 件",
        "机械键盘": "暂时缺货，预计 3 天后补货",
    }
    status = mock_inventory.get(product_name, f"未找到商品「{product_name}」的库存信息。")
    return f"商品「{product_name}」库存状态：{status}"
