"""
工单操作函数：创建工单、查询工单状态等
"""

import uuid
from datetime import datetime

# 模拟工单存储
_MOCK_TICKETS = {}


def create_ticket(user_id: str = "", issue: str = "", category: str = "") -> str:
    """创建正式工单"""
    ticket_id = f"TK-{uuid.uuid4().hex[:8].upper()}"
    _MOCK_TICKETS[ticket_id] = {
        "ticket_id": ticket_id,
        "user_id": user_id,
        "issue": issue,
        "category": category or "未分类",
        "status": "待处理",
        "created_at": datetime.now().isoformat(),
    }
    return (f"工单已创建，编号：{ticket_id}。"
            f"我们将在 24 小时内响应，请耐心等待。"
            f"您可在「我的工单」中查看处理进度。")


def query_ticket_status(ticket_id: str) -> str:
    """查询工单处理状态"""
    ticket = _MOCK_TICKETS.get(ticket_id)
    if not ticket:
        return f"未找到工单 {ticket_id}，请核实工单编号。"
    return f"工单 {ticket_id}：状态「{ticket['status']}」，提交时间 {ticket['created_at'][:10]}。"


def escalate_to_human(reason: str = "") -> str:
    """转人工客服"""
    return ("已为您转接人工客服。"
            "当前排队人数较多，预计等待 3-5 分钟，请耐心等候。"
            f"{'转接原因：' + reason if reason else ''}")
