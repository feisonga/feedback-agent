"""
Orchestrator —— LLM-native Agent 编排中心

替代旧架构的 PipelineRunner + Dispatcher + ResponseBuilder。
不预设执行流程，由 LLM 通过 ReAct 循环自主决定：
- 何时调用哪个工具
- 调用多少个工具
- 何时信息已足够，可以生成回复
"""
import logging
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional

from .tool_registry import ToolRegistry
from .memory import WorkingMemory, EpisodicMemory
from .react_loop import ReActLoop, ReActTrace
from .llm_client import AgentLLMClient

logger = logging.getLogger(__name__)


class AgentOrchestrator:
    """
    LLM-native 智能编排器

    工作流程:
    1. 用户消息到达
    2. ReAct 循环: LLM 分析 → 选择工具 → 执行 → 观察 → 继续/结束
    3. 返回最终回复 + 完整推理链路
    """

    def __init__(
        self,
        tool_registry: ToolRegistry,
        llm_client: AgentLLMClient,
        memory_db_path: str = None,
    ):
        self.tools = tool_registry
        self.llm = llm_client
        self._memory_db = memory_db_path or ":memory:"

        # 每个 session 有独立的工作记忆
        self._working_memories: Dict[str, WorkingMemory] = {}
        self._episodic = EpisodicMemory(self._memory_db)

    def get_or_create_memory(self, session_id: str) -> WorkingMemory:
        if session_id not in self._working_memories:
            self._working_memories[session_id] = WorkingMemory()
        return self._working_memories[session_id]

    async def process(
        self,
        user_message: str,
        session_id: str,
        context: Dict = None,
    ) -> Dict[str, Any]:
        """非流式处理一条用户消息"""
        wm = self.get_or_create_memory(session_id)

        # 注入外部上下文
        if context:
            for key, value in context.items():
                wm.set_context(key, value)

        loop = ReActLoop(
            llm_client=self.llm,
            tool_registry=self.tools,
            memory=wm,
            episodic_memory=self._episodic,
        )

        trace = await loop.run(user_message, session_id)

        # 记录关键事件到情节记忆
        self._record_episodes(session_id, trace)

        return self._build_response(trace)

    async def process_stream(
        self,
        user_message: str,
        session_id: str,
        context: Dict = None,
    ) -> AsyncIterator[Dict]:
        """流式处理，yield 推理步骤事件"""
        wm = self.get_or_create_memory(session_id)

        if context:
            for key, value in context.items():
                wm.set_context(key, value)

        loop = ReActLoop(
            llm_client=self.llm,
            tool_registry=self.tools,
            memory=wm,
            episodic_memory=self._episodic,
        )

        async for event in loop.run_stream(user_message, session_id):
            yield event

        # 记录关键事件
        self._record_episodes(session_id, None)

    def get_session_context(self, session_id: str) -> Dict[str, Any]:
        """获取会话当前上下文（供前端展示）"""
        wm = self._working_memories.get(session_id)
        if not wm:
            return {}
        return {
            "intent": wm.get_context("intent"),
            "sentiment": wm.get_context("sentiment"),
            "entities": wm.get_context("entities"),
            "urgency": wm.get_context("urgency"),
            "turn_count": len(wm),
        }

    async def get_analytics(self, session_id: str = None) -> Dict[str, Any]:
        """获取分析数据"""
        episodes = self._episodic.recall(session_id=session_id, limit=20)
        return {
            "total_episodes": len(episodes),
            "by_type": self._count_by_type(episodes),
            "recent": episodes[:5],
        }

    def _record_episodes(self, session_id: str, trace: ReActTrace = None):
        """记录关键事件到情节记忆"""
        wm = self._working_memories.get(session_id)
        if not wm:
            return

        # 记录意图
        intent = wm.get_context("intent")
        if intent:
            self._episodic.record(
                session_id=session_id,
                content=f"用户意图: {intent}",
                event_type="intent",
                importance=0.6,
            )

        # 记录紧急事件
        urgency = wm.get_context("urgency")
        if urgency in ("critical", "high"):
            self._episodic.record(
                session_id=session_id,
                content=f"紧急事件: {urgency}",
                event_type="urgency",
                importance=0.9,
            )

        # 记录升级
        if trace and trace.errors:
            self._episodic.record(
                session_id=session_id,
                content=f"处理异常: {trace.errors[0]}",
                event_type="error",
                importance=0.8,
            )

    def _build_response(self, trace: ReActTrace) -> Dict[str, Any]:
        return {
            "reply": trace.final_reply,
            "case": "llm_react",
            "agent_trace": {
                "steps": [
                    {
                        "step": s.step,
                        "thought": s.thought,
                        "tool_calls": [
                            {"name": tc["name"], "arguments": tc["arguments"]}
                            for tc in s.tool_calls
                        ],
                        "observations": [
                            {
                                "tool": obs.tool_name,
                                "success": obs.success,
                                "data": obs.data,
                                "confidence": obs.confidence,
                            }
                            for obs in s.observations
                        ],
                        "latency_ms": s.latency_ms,
                    }
                    for s in trace.steps
                ],
                "total_latency_ms": trace.total_latency_ms,
                "total_tool_calls": trace.total_tool_calls,
                "errors": trace.errors,
            },
        }

    def _count_by_type(self, episodes: List[Dict]) -> Dict[str, int]:
        counts = {}
        for ep in episodes:
            t = ep.get("type", "unknown")
            counts[t] = counts.get(t, 0) + 1
        return counts
