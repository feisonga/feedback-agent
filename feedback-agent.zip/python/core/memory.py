"""
Memory System —— 三层记忆体系

1. Working Memory: 当前会话上下文（最近 N 轮对话 + ReAct 轨迹）
2. Episodic Memory: 关键事件摘要（用户意图、情感拐点、升级事件）
3. Semantic Memory: 长期知识（向量化存储的 FAQ / 案例 / 政策片段）

设计原则：
- 轻量级，不依赖外部向量数据库
- 短期用滑动窗口，长期用 sqlite + np 余弦相似度
"""
import json
import logging
import sqlite3
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class MemoryEntry:
    """记忆条目"""
    id: str
    content: str
    role: str  # user / assistant / system / observation
    timestamp: float = field(default_factory=time.time)
    metadata: Dict = field(default_factory=dict)


class WorkingMemory:
    """工作记忆 —— 当前会话的滑动窗口"""

    def __init__(self, max_turns: int = 20, max_tokens_est: int = 8000):
        self.max_turns = max_turns
        self.max_tokens_est = max_tokens_est
        self._entries: List[MemoryEntry] = []
        self._context: Dict[str, Any] = {}  # 会话级上下文变量

    def add(self, content: str, role: str, metadata: Dict = None):
        self._entries.append(MemoryEntry(
            id=f"wm_{len(self._entries)}",
            content=content,
            role=role,
            metadata=metadata or {},
        ))
        self._trim()

    def set_context(self, key: str, value: Any):
        self._context[key] = value

    def get_context(self, key: str, default=None):
        return self._context.get(key, default)

    def get_recent(self, n: int = 10) -> List[MemoryEntry]:
        return self._entries[-n:]

    def get_conversation_history(self) -> List[Dict]:
        """获取 OpenAI 格式的对话历史"""
        return [
            {"role": e.role, "content": e.content}
            for e in self._entries
            if e.role in ("user", "assistant")
        ]

    def get_observations(self) -> List[str]:
        """获取所有 Observation（工具执行结果）"""
        return [e.content for e in self._entries if e.role == "observation"]

    def _trim(self):
        """保持工作记忆在限制内"""
        while len(self._entries) > self.max_turns * 2:
            self._entries.pop(0)

    def clear(self):
        self._entries.clear()
        self._context.clear()

    def __len__(self) -> int:
        return len(self._entries)


class EpisodicMemory:
    """情节记忆 —— 跨会话的关键事件摘要"""

    def __init__(self, db_path: str = ":memory:"):
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS episodes (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                content TEXT NOT NULL,
                event_type TEXT NOT NULL,
                importance REAL DEFAULT 0.5,
                created_at REAL NOT NULL
            )
        """)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_eps_session ON episodes(session_id)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_eps_type ON episodes(event_type)")
        self._conn.commit()

    def record(self, session_id: str, content: str, event_type: str, importance: float = 0.5):
        import uuid
        self._conn.execute(
            "INSERT INTO episodes (id, session_id, content, event_type, importance, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), session_id, content, event_type, importance, time.time()),
        )
        self._conn.commit()

    def recall(self, session_id: str = None, event_type: str = None, limit: int = 5) -> List[Dict]:
        query = "SELECT content, event_type, importance FROM episodes WHERE 1=1"
        params = []
        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)
        if event_type:
            query += " AND event_type = ?"
            params.append(event_type)
        query += " ORDER BY importance DESC, created_at DESC LIMIT ?"
        params.append(limit)

        rows = self._conn.execute(query, params).fetchall()
        return [
            {"content": r[0], "type": r[1], "importance": r[2]}
            for r in rows
        ]

    def summarize_for_prompt(self, session_id: str) -> str:
        """生成可注入 system prompt 的记忆摘要"""
        episodes = self.recall(session_id=session_id, limit=5)
        if not episodes:
            return ""
        lines = ["## 历史关键事件"]
        for ep in episodes:
            lines.append(f"- [{ep['type']}] {ep['content']}")
        return "\n".join(lines)


class SemanticMemory:
    """语义记忆 —— 长期知识的向量化存储

    使用轻量 numpy + json 方案，不依赖外部向量数据库。
    """

    def __init__(self, storage_path: str = None):
        self._entries: List[Dict] = []
        self._embeddings: Optional[Any] = None
        self._model = None
        self._storage_path = storage_path

    def _ensure_model(self):
        if self._model is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(
                "paraphrase-multilingual-MiniLM-L12-v2",
                local_files_only=True,
            )
        except Exception:
            logger.warning("SemanticMemory: 无法加载 embedding 模型")
            self._model = False

    def add(self, text: str, metadata: Dict = None):
        self._entries.append({
            "text": text,
            "metadata": metadata or {},
            "timestamp": time.time(),
        })
        # Invalidate cached embeddings
        self._embeddings = None

    def search(self, query: str, top_k: int = 3) -> List[Dict]:
        self._ensure_model()
        if not self._model or not self._entries:
            return []

        import numpy as np
        if self._embeddings is None:
            texts = [e["text"] for e in self._entries]
            self._embeddings = self._model.encode(
                texts, normalize_embeddings=True
            ).astype(np.float32)

        query_emb = self._model.encode(
            [query], normalize_embeddings=True
        ).astype(np.float32)

        scores = np.dot(query_emb, self._embeddings.T)[0]
        top_indices = np.argsort(scores)[-top_k:][::-1]

        results = []
        for idx in top_indices:
            if scores[idx] > 0.3:
                results.append({
                    **self._entries[idx],
                    "score": float(scores[idx]),
                })
        return results
