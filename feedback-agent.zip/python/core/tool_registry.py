"""
Tool Registry —— 工具注册、发现、执行

统一管理所有 Agent Tool，支持：
- 按意图/关键词自动发现工具
- 按类别过滤
- 生成 OpenAI 兼容的工具列表
"""
import inspect
import logging
from typing import Callable, Dict, List, Optional

from .tool_schema import ToolSchema, ToolResult

logger = logging.getLogger(__name__)


class ToolRegistry:
    """LLM-native 工具注册中心"""

    def __init__(self):
        self._tools: Dict[str, ToolSchema] = {}
        self._by_category: Dict[str, List[str]] = {}

    def register(
        self,
        name: str,
        description: str,
        category: str = "analysis",
        *,
        parameters: Dict = None,
        required: List[str] = None,
        trigger_keywords: List[str] = None,
        cost_estimate: str = "low",
        is_async: bool = False,
    ):
        """装饰器工厂：注册函数为 Tool"""

        def decorator(fn: Callable):
            params = parameters or {}
            req = required or []
            if not params and not req:
                params, req = self._infer_from_signature(fn)

            schema = ToolSchema(
                name=name,
                description=description,
                category=category,
                trigger_keywords=trigger_keywords or [],
                parameters=params,
                required=req,
                fn=fn,
                cost_estimate=cost_estimate,
                is_async=is_async,
            )
            self._tools[name] = schema
            self._by_category.setdefault(category, []).append(name)
            logger.debug(f"Registered tool: {name} [{category}]")
            return fn

        return decorator

    def register_raw(self, schema: ToolSchema):
        """直接注册已构建好的 ToolSchema"""
        self._tools[schema.name] = schema
        self._by_category.setdefault(schema.category, []).append(schema.name)

    def get(self, name: str) -> Optional[ToolSchema]:
        return self._tools.get(name)

    def list_by_category(self, category: str = None) -> List[ToolSchema]:
        if category:
            return [self._tools[n] for n in self._by_category.get(category, [])]
        return list(self._tools.values())

    def find_by_keywords(self, text: str, top_k: int = 8) -> List[ToolSchema]:
        """根据文本关键词匹配工具"""
        scored = []
        text_lower = text.lower()
        for tool in self._tools.values():
            score = sum(1 for kw in tool.trigger_keywords if kw in text_lower)
            if score > 0:
                scored.append((score, tool))
        scored.sort(key=lambda x: -x[0])
        return [t for _, t in scored[:top_k]]

    def get_openai_tools(self, category: str = None) -> List[dict]:
        """生成 OpenAI 兼容的 tools 列表"""
        tools = self.list_by_category(category)
        return [t.to_openai_tool() for t in tools]

    def get_all_openai_tools(self) -> List[dict]:
        """生成所有工具的 OpenAI 格式"""
        return [t.to_openai_tool() for t in self._tools.values()]

    def execute(self, name: str, **kwargs) -> ToolResult:
        """执行指定工具"""
        tool = self.get(name)
        if not tool:
            return ToolResult(
                tool_name=name,
                success=False,
                error=f"未注册的工具: {name}",
            )
        if not tool.fn:
            return ToolResult(
                tool_name=name,
                success=False,
                error=f"工具 {name} 无可执行实现",
            )
        try:
            result = tool.fn(**kwargs)
            if isinstance(result, ToolResult):
                return result
            return ToolResult(
                tool_name=name,
                success=True,
                data=result,
            )
        except Exception as e:
            logger.error(f"Tool [{name}] 执行失败: {e}")
            return ToolResult(
                tool_name=name,
                success=False,
                error=str(e),
            )

    def _infer_from_signature(self, fn: Callable) -> tuple[Dict, List[str]]:
        """从函数签名推断参数定义"""
        sig = inspect.signature(fn)
        params = {}
        required = []
        for pname, param in sig.parameters.items():
            if pname in ("self", "cls"):
                continue
            anno = param.annotation if param.annotation is not inspect.Parameter.empty else str
            type_map = {str: "string", int: "integer", float: "number", bool: "boolean"}
            params[pname] = {
                "type": type_map.get(anno, "string"),
                "description": "",
            }
            if param.default is inspect.Parameter.empty:
                required.append(pname)
        return params, required

    def __len__(self) -> int:
        return len(self._tools)

    def __repr__(self) -> str:
        cats = {c: len(names) for c, names in self._by_category.items()}
        return f"ToolRegistry({len(self._tools)} tools, cats={cats})"


