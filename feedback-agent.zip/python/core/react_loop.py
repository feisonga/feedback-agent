"""
ReAct Loop Engine —— Thought → Action → Observation 循环

核心执行单元：
1. LLM 推理：分析当前状态，决定下一步（调用工具 or 生成回复）
2. 工具执行：并行调用 LLM 选择的 tools
3. 观察注入：将 tool 结果注入上下文
4. 循环终止：LLM 决定已收集足够信息，生成最终回复
"""
import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional

from .tool_schema import ToolResult

logger = logging.getLogger(__name__)


@dataclass
class ReActStep:
    """ReAct 单步记录"""
    step: int
    thought: str = ""
    tool_calls: List[Dict] = field(default_factory=list)
    observations: List[ToolResult] = field(default_factory=list)
    latency_ms: int = 0


@dataclass
class ReActTrace:
    """完整的 ReAct 推理链路"""
    session_id: str
    user_message: str
    steps: List[ReActStep] = field(default_factory=list)
    final_reply: str = ""
    total_latency_ms: int = 0
    total_tokens: int = 0
    total_tool_calls: int = 0
    errors: List[str] = field(default_factory=list)


REACT_SYSTEM_PROMPT = """你是乡村社区智能助手"社工老王"，服务对象是乡村志愿者和村民。

## 核心能力
你拥有一系列分析工具（意图识别、情感分析、实体提取、紧急度评估、FAQ检索、政策匹配、相似案例搜索、对话追踪），可以调用它们来理解用户问题并给出准确的回复。

## 工作方式
对于每条用户消息，按以下流程处理：
1. **分析**：使用分析工具理解用户的意图、情感和紧急程度
2. **检索**：如需相关知识，使用检索工具查找 FAQ、政策和历史案例
3. **回复**：综合所有信息，生成温暖、实用、落地的回复

## 工具使用原则
- 优先并行调用独立工具（如意图识别+情感分析+实体提取可以同时进行）
- 紧急/愤怒情绪时优先安抚，不要冷冰冰地罗列信息
- FAQ 和政策匹配到的内容要转化为自然口语，不能照搬原文
- 不确定的事情诚实说"不确定"，涉及政策法律时注明"建议进一步咨询相关部门"

## 回复风格
- 亲切、朴实、有温度，像邻里之间的对话
- 先共情 → 再给方案 → 最后表达持续支持
- 理解乡村生活的实际情况，建议要落地可行
"""


class ReActLoop:
    """ReAct 推理-行动 循环执行引擎"""

    MAX_STEPS = 5  # 最多 5 步推理
    MAX_TOKENS_PER_REPLY = 1024

    def __init__(self, llm_client, tool_registry, memory, system_prompt: str = None, episodic_memory=None):
        self.llm = llm_client
        self.tools = tool_registry
        self.memory = memory
        self.episodic = episodic_memory
        self.system_prompt = system_prompt or REACT_SYSTEM_PROMPT

    async def run(self, user_message: str, session_id: str) -> ReActTrace:
        """运行 ReAct 循环，返回完整推理链路"""
        t0 = time.perf_counter()
        trace = ReActTrace(session_id=session_id, user_message=user_message)

        # 记录用户消息到工作记忆
        self.memory.add(user_message, role="user", metadata={"session_id": session_id})

        # 构建消息列表
        messages = self._build_messages(user_message, session_id)

        for step_num in range(1, self.MAX_STEPS + 1):
            t_step = time.perf_counter()
            react_step = ReActStep(step=step_num)

            try:
                response = await self.llm.client.chat.completions.create(
                    model=self.llm.model,
                    messages=messages,
                    tools=self.tools.get_all_openai_tools(),
                    tool_choice="auto",
                    temperature=0.3,
                    max_tokens=4096,
                )
            except Exception as e:
                logger.error(f"LLM 调用失败 (step {step_num}): {e}")
                trace.errors.append(f"Step {step_num}: {e}")
                break

            choice = response.choices[0]
            msg = choice.message
            react_step.latency_ms = int((time.perf_counter() - t_step) * 1000)

            # 检查是否有 tool calls
            if msg.tool_calls:
                react_step.thought = msg.content or ""

                # 记录 assistant 消息（带 tool_calls）
                messages.append({
                    "role": "assistant",
                    "content": msg.content,
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in msg.tool_calls
                    ],
                })

                # 并行执行所有 tool calls
                tool_calls_info = []
                observations = []

                for tc in msg.tool_calls:
                    tool_name = tc.function.name
                    try:
                        args = json.loads(tc.function.arguments)
                    except json.JSONDecodeError:
                        args = {}

                    tool_calls_info.append({
                        "id": tc.id,
                        "name": tool_name,
                        "arguments": args,
                    })
                    react_step.tool_calls.append(tool_calls_info[-1])

                    # 注入上下文
                    args.setdefault("context", self.memory._context)

                    # 执行工具
                    result = self.tools.execute(tool_name, **args)
                    observations.append(result)

                    # 注入工具结果到消息
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result.to_observation(),
                    })

                    # 记录到工作记忆
                    self.memory.add(
                        result.to_observation(),
                        role="observation",
                        metadata={"tool": tool_name},
                    )

                react_step.observations = observations
                trace.total_tool_calls += len(tool_calls_info)
                trace.steps.append(react_step)

                # 更新上下文
                self._update_context(observations)

            else:
                # 最终回复
                react_step.thought = "生成最终回复"
                trace.steps.append(react_step)
                trace.final_reply = msg.content or ""
                break

        # 降级：如果循环完没有回复
        if not trace.final_reply:
            trace.final_reply = self._fallback_reply()

        # 记录助手回复到工作记忆
        self.memory.add(trace.final_reply, role="assistant")

        trace.total_latency_ms = int((time.perf_counter() - t0) * 1000)
        return trace

    async def run_stream(self, user_message: str, session_id: str) -> AsyncIterator[Dict]:
        """流式执行 ReAct，实时 yield 事件"""
        trace = await self.run(user_message, session_id)

        for step in trace.steps:
            yield {
                "type": "react_step",
                "step": step.step,
                "thought": step.thought,
                "tool_calls": [
                    {"name": tc["name"], "arguments": tc["arguments"]}
                    for tc in step.tool_calls
                ],
                "observations": [
                    {"tool": obs.tool_name, "success": obs.success, "data": obs.data}
                    for obs in step.observations
                ],
                "latency_ms": step.latency_ms,
            }

        yield {
            "type": "message_complete",
            "reply": trace.final_reply,
            "total_latency_ms": trace.total_latency_ms,
            "total_tool_calls": trace.total_tool_calls,
        }

    def _build_messages(self, user_message: str, session_id: str) -> List[Dict]:
        messages = [{"role": "system", "content": self._build_system_prompt(session_id)}]

        # 注入工作记忆中的最近对话
        for entry in self.memory.get_recent(10):
            if entry.role in ("user", "assistant"):
                messages.append({"role": entry.role, "content": entry.content})

        # 添加当前用户消息
        messages.append({"role": "user", "content": user_message})
        return messages

    def _build_system_prompt(self, session_id: str) -> str:
        parts = [self.system_prompt]

        # 注入情节记忆
        if self.episodic and hasattr(self.episodic, 'summarize_for_prompt'):
            ep_summary = self.episodic.summarize_for_prompt(session_id)
            if ep_summary:
                parts.append(f"\n{ep_summary}")

        # 注入对话上下文
        context = self.memory._context
        if context:
            ctx_lines = ["\n## 当前会话上下文"]
            if "intent" in context:
                ctx_lines.append(f"- 识别意图: {context['intent']}")
            if "sentiment" in context:
                ctx_lines.append(f"- 用户情绪: {context['sentiment']}")
            if "entities" in context:
                ctx_lines.append(f"- 提取实体: {json.dumps(context['entities'], ensure_ascii=False)}")
            if "urgency" in context:
                ctx_lines.append(f"- 紧急程度: {context['urgency']}")
            parts.append("\n".join(ctx_lines))

        return "\n".join(parts)

    def _update_context(self, observations: List[ToolResult]):
        """从工具结果更新会话上下文"""
        for obs in observations:
            if not obs.success:
                continue
            data = obs.data
            if not isinstance(data, dict):
                continue

            if "intent" in data:
                self.memory.set_context("intent", data["intent"])
            if "sentiment" in data:
                self.memory.set_context("sentiment", data["sentiment"])
            if "entities" in data:
                self.memory.set_context("entities", data["entities"])
            if "urgency" in data:
                self.memory.set_context("urgency", data["urgency"])

    def _fallback_reply(self) -> str:
        context = self.memory._context
        intent = context.get("intent", "")
        if intent:
            return f"已收到您的{intent}需求，正在为您处理，请稍候。"
        return "已收到您的消息，正在为您处理，请稍候。"
