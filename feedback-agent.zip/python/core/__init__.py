"""
Feedback Agent Core — LLM-native Agent 基础设施

ReAct 循环 · Tool 管理 · 记忆系统 · 智能编排
"""
