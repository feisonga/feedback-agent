"""
Tool Schema 定义 —— OpenAI Function Calling 兼容格式 + 扩展元数据
"""
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional
import inspect
import json


@dataclass
class ToolResult:
    """工具执行统一输出"""
    tool_name: str
    success: bool
    data: Any = None
    error: str = ""
    confidence: float = 1.0
    evidence: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)

    def to_observation(self) -> str:
        """转为 ReAct Observation 文本，简洁可注入"""
        if self.success:
            summary = json.dumps(self.data, ensure_ascii=False, default=str)
            if len(summary) > 800:
                summary = summary[:797] + "..."
            conf_str = f" [置信度:{self.confidence:.0%}]" if self.confidence < 1.0 else ""
            return f"[{self.tool_name}]{conf_str} 结果: {summary}"
        return f"[{self.tool_name}] 失败: {self.error}"


@dataclass
class ToolSchema:
    """工具元数据 —— 兼容 OpenAI Function Calling + 额外信息"""
    name: str
    description: str
    category: str  # analysis / retrieval / action / system
    trigger_keywords: List[str] = field(default_factory=list)
    parameters: Dict[str, Any] = field(default_factory=dict)
    required: List[str] = field(default_factory=list)
    fn: Optional[Callable] = None
    cost_estimate: str = "low"  # low / medium / high (token cost)
    is_async: bool = False

    def to_openai_tool(self) -> dict:
        """转为 OpenAI tool 格式 (parallel function calling)"""
        props = {}
        for name, info in self.parameters.items():
            props[name] = {
                "type": info.get("type", "string"),
                "description": info.get("description", ""),
            }
            if "enum" in info:
                props[name]["enum"] = info["enum"]
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": props,
                    "required": self.required,
                },
            },
        }

    def __repr__(self) -> str:
        return f"Tool({self.name}, cat={self.category})"
