"""
LLM Client —— 为 Agent 推理提供的 OpenAI 兼容 API 封装

每个 Agent Tool 可用此客户端进行 LLM 推理调用。
"""
import json
import logging
from typing import Any, AsyncIterator, Dict, List, Optional

from openai import AsyncOpenAI

logger = logging.getLogger(__name__)


class AgentLLMClient:
    """Agent 推理用 LLM 客户端，支持同步/异步/流式"""

    def __init__(
        self,
        api_key: str = "",
        base_url: str = "https://api.deepseek.com/v1",
        model: str = "deepseek-chat",
        temperature: float = 0.3,
    ):
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        self.temperature = temperature
        self._client: Optional[AsyncOpenAI] = None

    @property
    def client(self) -> AsyncOpenAI:
        if self._client is None:
            self._client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
            )
        return self._client

    @property
    def available(self) -> bool:
        return bool(self.api_key)

    async def chat(
        self,
        messages: List[Dict],
        tools: List[Dict] = None,
        temperature: float = None,
        max_tokens: int = 1024,
        response_format: Dict = None,
    ) -> Any:
        """标准 Chat Completion 封装"""
        kwargs = dict(
            model=self.model,
            messages=messages,
            temperature=temperature or self.temperature,
            max_tokens=max_tokens,
        )
        if tools:
            kwargs["tools"] = tools
        if response_format:
            kwargs["response_format"] = response_format

        return await self.client.chat.completions.create(**kwargs)

    async def chat_stream(
        self,
        messages: List[Dict],
        max_tokens: int = 1024,
    ) -> AsyncIterator[str]:
        """流式 Chat Completion"""
        stream = await self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=self.temperature,
            max_tokens=max_tokens,
            stream=True,
        )
        async for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

    async def classify(
        self,
        text: str,
        instruction: str,
        categories: List[str],
    ) -> Dict[str, Any]:
        """通用分类调用"""
        cat_str = ", ".join(categories)
        response = await self.chat(
            messages=[
                {"role": "system", "content": f"{instruction}\n可选类别: {cat_str}\n请只返回 JSON 格式: {{\"category\": \"...\", \"confidence\": 0.0-1.0, \"reasoning\": \"...\"}}"},
                {"role": "user", "content": text},
            ],
            temperature=0.1,
            max_tokens=256,
            response_format={"type": "json_object"},
        )
        import json
        try:
            return json.loads(response.choices[0].message.content)
        except (json.JSONDecodeError, AttributeError):
            content = response.choices[0].message.content or ""
            return {"category": categories[0], "confidence": 0.3, "reasoning": content}

    async def extract(
        self,
        text: str,
        instruction: str,
        schema: Dict,
    ) -> Dict[str, Any]:
        """通用结构化提取调用"""
        response = await self.chat(
            messages=[
                {"role": "system", "content": f"{instruction}\n请只返回 JSON 格式，严格遵循以下 schema:\n{json.dumps(schema, ensure_ascii=False)}"},
                {"role": "user", "content": text},
            ],
            temperature=0.1,
            max_tokens=512,
            response_format={"type": "json_object"},
        )
        import json
        try:
            return json.loads(response.choices[0].message.content)
        except (json.JSONDecodeError, AttributeError):
            return {}
