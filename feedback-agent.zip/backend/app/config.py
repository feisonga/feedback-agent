from pathlib import Path
from pydantic_settings import BaseSettings

_ENV_FILE = Path(__file__).resolve().parent.parent / ".env"


class Settings(BaseSettings):
    model_config = {"env_file": str(_ENV_FILE), "env_file_encoding": "utf-8"}

    # Server
    host: str = "0.0.0.0"
    port: int = 3100
    debug: bool = True

    # Database
    database_url: str = "sqlite+aiosqlite:///./feedback.db"

    # Knowledge base
    knowledge_base_path: str = ""

    # LLM (OpenAI-compatible)
    openai_api_key: str = ""
    openai_base_url: str = "https://api.deepseek.com/v1"
    model_name: str = "deepseek-chat"
    llm_temperature: float = 0.3
    llm_max_tokens: int = 4096
    max_react_steps: int = 5
    max_llm_calls_per_minute: int = 30

    # Agent
    use_llm_agents: bool = True  # True=LLM驱动, False=规则回退

    @property
    def resolved_kb_path(self) -> Path:
        if self.knowledge_base_path:
            return Path(self.knowledge_base_path)
        return Path(__file__).resolve().parent.parent.parent / "python" / "knowledge"


settings = Settings()
