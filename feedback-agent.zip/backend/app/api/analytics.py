from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from ..dependencies import get_db_session
from ..schemas.common import Envelope
from ..services.analytics_service import AnalyticsService

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/overview")
async def overview(days: int = Query(30, ge=1, le=365), db: AsyncSession = Depends(get_db_session)):
    svc = AnalyticsService(db)
    data = await svc.overview(days)
    return Envelope(data=data)


@router.get("/agent-performance")
async def agent_performance(days: int = Query(30, ge=1, le=365), db: AsyncSession = Depends(get_db_session)):
    svc = AnalyticsService(db)
    data = await svc.agent_performance(days)
    return Envelope(data=data)
