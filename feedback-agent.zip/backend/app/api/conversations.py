from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from ..dependencies import get_db_session
from ..schemas.common import Envelope, PaginatedResponse
from ..models.conversation import Conversation, Message

router = APIRouter(prefix="/api/conversations", tags=["conversations"])


@router.get("")
async def list_conversations(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session),
):
    count_result = await db.execute(select(func.count(Conversation.id)))
    total = count_result.scalar() or 0

    result = await db.execute(
        select(Conversation)
        .order_by(Conversation.updated_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )
    conversations = result.scalars().all()

    items = [
        {
            "id": c.id,
            "title": c.title,
            "status": c.status,
            "created_at": c.created_at.isoformat() if c.created_at else "",
            "updated_at": c.updated_at.isoformat() if c.updated_at else "",
        }
        for c in conversations
    ]

    return Envelope(data=PaginatedResponse(items=items, total=total, page=page, page_size=page_size))


@router.get("/{conversation_id}")
async def get_conversation(conversation_id: str, db: AsyncSession = Depends(get_db_session)):
    result = await db.execute(
        select(Conversation).where(Conversation.id == conversation_id)
    )
    conv = result.scalar_one_or_none()
    if conv is None:
        return Envelope(code=404, message="Not found", data=None)

    msgs_result = await db.execute(
        select(Message)
        .where(Message.conversation_id == conversation_id)
        .order_by(Message.created_at)
    )
    messages = msgs_result.scalars().all()

    return Envelope(data={
        "id": conv.id,
        "title": conv.title,
        "status": conv.status,
        "created_at": conv.created_at.isoformat() if conv.created_at else "",
        "updated_at": conv.updated_at.isoformat() if conv.updated_at else "",
        "messages": [
            {
                "id": m.id,
                "role": m.role,
                "content": m.content,
                "intent": m.intent,
                "sentiment": m.sentiment,
                "urgency": m.urgency,
                "agent_trace": m.agent_trace,
                "dispatch_case": m.dispatch_case,
                "latency_ms": m.latency_ms,
                "created_at": m.created_at.isoformat() if m.created_at else "",
            }
            for m in messages
        ],
    })


@router.delete("/{conversation_id}")
async def delete_conversation(conversation_id: str, db: AsyncSession = Depends(get_db_session)):
    result = await db.execute(
        select(Conversation).where(Conversation.id == conversation_id)
    )
    conv = result.scalar_one_or_none()
    if conv is None:
        return Envelope(code=404, message="Not found", data=None)

    # Delete messages first
    await db.execute(
        select(Message).where(Message.conversation_id == conversation_id)
    )
    msgs_result = await db.execute(
        select(Message).where(Message.conversation_id == conversation_id)
    )
    for m in msgs_result.scalars().all():
        await db.delete(m)

    await db.delete(conv)
    await db.commit()
    return Envelope(data={"deleted": conversation_id})


@router.post("/{conversation_id}/feedback")
async def feedback(conversation_id: str, db: AsyncSession = Depends(get_db_session)):
    result = await db.execute(
        select(Conversation).where(Conversation.id == conversation_id)
    )
    conv = result.scalar_one_or_none()
    if conv is None:
        return Envelope(code=404, message="Not found", data=None)
    return Envelope(data={"success": True})
