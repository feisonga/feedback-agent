from fastapi import APIRouter, Request
from ..schemas.common import Envelope

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check(request: Request):
    orch = getattr(request.app.state, "orchestrator", None)
    tool_count = len(orch.tools) if orch else 0
    llm_available = orch.llm.available if orch else False
    return Envelope(data={
        "status": "ok",
        "version": "2.0.0-llm-native",
        "architecture": "ReAct + Tool-use + Memory",
        "tools_loaded": tool_count,
        "llm_available": llm_available,
        "llm_model": orch.llm.model if orch else "N/A",
    })
