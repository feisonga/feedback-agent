import uuid
from datetime import datetime

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from ..dependencies import get_db_session
from ..models.conversation import Conversation
from ..models.session_model import ChatSession
from ..schemas.common import Envelope
from ..schemas.chat import SessionCreateRequest, SessionRead

router = APIRouter(prefix="/api/sessions", tags=["sessions"])


@router.post("")
async def create_session(
    body: SessionCreateRequest = SessionCreateRequest(),
    db: AsyncSession = Depends(get_db_session),
):
    conv_id = str(uuid.uuid4())
    session_id = str(uuid.uuid4())
    now = datetime.utcnow()

    conv = Conversation(id=conv_id, title="新对话", user_id=body.user_id, created_at=now, updated_at=now)
    sess = ChatSession(id=session_id, conversation_id=conv_id, state={}, created_at=now)

    db.add(conv)
    db.add(sess)
    await db.commit()

    return Envelope(data={
        "session_id": session_id,
        "conversation_id": conv_id,
        "created_at": now.isoformat(),
    })


@router.get("/{session_id}")
async def get_session(session_id: str, db: AsyncSession = Depends(get_db_session)):
    result = await db.execute(select(ChatSession).where(ChatSession.id == session_id))
    sess = result.scalar_one_or_none()
    if sess is None:
        return Envelope(code=404, message="会话不存在", data=None)

    conv_result = await db.execute(select(Conversation).where(Conversation.id == sess.conversation_id))
    conv = conv_result.scalar_one_or_none()

    return Envelope(data={
        "session_id": sess.id,
        "conversation_id": sess.conversation_id,
        "status": conv.status if conv else "unknown",
        "created_at": sess.created_at.isoformat(),
    })
