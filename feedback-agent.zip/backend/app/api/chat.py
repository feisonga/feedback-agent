"""
Chat API —— 基于 LLM-native AgentOrchestrator 的 REST + WebSocket 路由
"""
import json
import logging

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession

from ..dependencies import get_db_session
from ..schemas.common import Envelope
from ..schemas.chat import ChatRequest
from ..services.chat_service import ChatService

logger = logging.getLogger(__name__)

router = APIRouter(tags=["chat"])
ws_router = APIRouter(tags=["chat_ws"])


@router.post("/api/chat/send")
async def chat_send(body: ChatRequest, db: AsyncSession = Depends(get_db_session)):
    """发送消息，返回 LLM Agent 完整回复 + ReAct 推理链路"""
    svc = ChatService(db)
    result = await svc.process_message(body.session_id, body.message, body.context)
    return Envelope(data=result)


@ws_router.websocket("/ws/chat/{session_id}")
async def chat_websocket(websocket: WebSocket, session_id: str):
    """流式对话：实时推送 ReAct 推理步骤 + 最终回复"""
    await websocket.accept()
    svc = ChatService(None)

    try:
        while True:
            raw = await websocket.receive_text()
            msg = json.loads(raw)
            if msg.get("type") != "message":
                await websocket.send_json({"type": "pong"})
                continue

            text = msg.get("content", "")
            if not text:
                continue

            async for event in svc.process_stream(session_id, text):
                await websocket.send_json(event)

            await websocket.send_json({"type": "message_end"})

    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected: {session_id}")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
