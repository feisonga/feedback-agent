from sqlalchemy.ext.asyncio import AsyncSession
from .models.database import get_db, get_session_factory
from .config import settings


# Session factory — initialized once at startup
_session_factory = None


async def init_db(database_url: str | None = None):
    """Initialize database engine and session factory. Called at startup."""
    global _session_factory
    url = database_url or settings.database_url
    _session_factory = get_session_factory(url)
    from .models.database import create_tables
    await create_tables(url)


async def get_db_session() -> AsyncSession:
    """FastAPI dependency: yields an async database session."""
    async with _session_factory() as session:
        try:
            yield session
        finally:
            await session.close()
