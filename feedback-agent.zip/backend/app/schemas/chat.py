import uuid
from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field


def _new_id() -> str:
    return str(uuid.uuid4())


# ── Request ──

class ChatRequest(BaseModel):
    session_id: str
    message: str
    context: dict[str, Any] = Field(default_factory=dict)


# ── Agent trace ──

class AgentTraceItem(BaseModel):
    agent_name: str
    result: Any
    confidence: float
    evidence: list[str]


class DispatchDecision(BaseModel):
    case: str  # A | B | C
    reasoning: str


class TracePayload(BaseModel):
    phase1: list[AgentTraceItem]
    phase2: list[AgentTraceItem]
    decision: DispatchDecision
    latency_ms: int


# ── Response ──

class ChatResponse(BaseModel):
    message_id: str = Field(default_factory=_new_id)
    session_id: str
    reply: str
    case: str
    intent: str | None = None
    sentiment: str | None = None
    urgency: str | None = None
    agent_trace: TracePayload | None = None


# ── Session ──

class SessionCreateRequest(BaseModel):
    user_id: str | None = None


class SessionRead(BaseModel):
    session_id: str
    conversation_id: str
    status: str
    created_at: str


# ── WebSocket events ──

class WsEvent(BaseModel):
    type: str
    payload: dict[str, Any] | None = None
