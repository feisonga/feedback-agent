"""
Feedback Agent —— LLM-native 智能客服系统入口

架构: LLM 推理 + ReAct 循环 + Tool-use + 记忆系统
"""
import os as _os
_os.environ.setdefault("HF_HUB_OFFLINE", "1")

import sys
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

_AGENTS_PATH = Path(__file__).resolve().parent.parent.parent / "python"
if str(_AGENTS_PATH) not in sys.path:
    sys.path.insert(0, str(_AGENTS_PATH))

from .config import settings
from .dependencies import init_db
from .api.router import api_router
from .api.chat import ws_router
from .core.orchestrator import get_orchestrator

AGENT_TOOLS = [
    "intent_classify", "sentiment_analyze", "entity_extract",
    "urgency_assess", "faq_retrieve", "policy_search",
    "similar_case_search", "dialogue_track",
]


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db(settings.database_url)
    orch = get_orchestrator()
    app.state.orchestrator = orch
    app.state.agent_tools = AGENT_TOOLS
    yield


app = FastAPI(
    title="Feedback Agent API",
    description="LLM-native 智能客服反馈系统 — ReAct 推理 + Tool-use + 记忆系统",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)
app.include_router(ws_router)


def main():
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
    )


if __name__ == "__main__":
    main()
