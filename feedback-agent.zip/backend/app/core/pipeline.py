import asyncio
import time
from typing import Any, Dict, List

from agents import AgentResult


class PipelineRunner:
    """3-phase agent execution engine."""

    def __init__(self, registry):
        self.registry = registry

    async def run_phase1(self, text: str, context: Dict[str, Any]) -> List[AgentResult]:
        """Phase 1 (parallel): Intent + Entity + Sentiment (~10-50ms, pure regex/dict)."""
        agents = self.registry._phase1_agents
        return await self._run_all(agents, text, context)

    async def run_phase2(
        self, text: str, session_id: str, phase1_results: List[AgentResult], context: Dict[str, Any]
    ) -> List[AgentResult]:
        """Phase 2 (parallel): Urgency + Dialog + FAQ + Case + Policy (~50-200ms)."""
        enriched = {**context}
        for r in phase1_results:
            if r.agent_name == "intent_classifier":
                enriched["intent"] = r.result.get("intent") if isinstance(r.result, dict) else r.result
            elif r.agent_name == "sentiment_analyzer":
                enriched["sentiment"] = r.result.get("sentiment") if isinstance(r.result, dict) else r.result
                enriched["sentiment_intensity"] = r.result.get("intensity", 0) if isinstance(r.result, dict) else 0
            elif r.agent_name == "entity_extractor":
                enriched["entities"] = r.result.get("entities") if isinstance(r.result, dict) else r.result

        enriched["session_id"] = session_id

        agents = self.registry._phase2_agents
        return await self._run_all(agents, text, enriched)

    async def _run_all(
        self, agents, text: str, context: Dict[str, Any]
    ) -> List[AgentResult]:
        loop = asyncio.get_running_loop()
        tasks = [
            loop.run_in_executor(None, agent.process, text, context)
            for agent in agents
        ]
        return await asyncio.gather(*tasks)

    async def run_full(
        self, text: str, session_id: str, context: Dict[str, Any] | None = None
    ) -> Dict[str, Any]:
        ctx = context or {}
        t0 = time.perf_counter()

        p1 = await self.run_phase1(text, ctx)
        p2 = await self.run_phase2(text, session_id, p1, ctx)

        all_results = {
            r.agent_name: {
                "result": r.result,
                "confidence": r.confidence,
                "evidence": r.evidence,
                "metadata": r.metadata,
            }
            for r in p1 + p2
        }

        latency_ms = int((time.perf_counter() - t0) * 1000)
        return {"results": all_results, "latency_ms": latency_ms, "phase1": p1, "phase2": p2}
