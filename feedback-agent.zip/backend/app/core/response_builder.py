from typing import Any, Dict

from utils.person_swap import system_to_user


class ResponseBuilder:
    """Builds replies for Case A (rule-based) and Case B (template)."""

    def build_rule_reply(self, agent_results: Dict[str, Any]) -> str:
        """
        Case A: All agents confident. Use FAQ/Policy/Case directly.
        Priority: FAQ > Policy > Case > Template
        """
        # 1. FAQ exact match
        faq = agent_results.get("FAQRetriever", {})
        if faq.get("confidence", 0) >= 0.75:
            matched = faq.get("result", {}).get("matched", {})
            if matched and matched.get("answer"):
                return self._format(matched["answer"])

        # 2. Policy article match
        policy = agent_results.get("PolicyMatcher", {})
        if policy.get("confidence", 0) >= 0.7:
            matched = policy.get("result", {}).get("matched", {})
            if matched and matched.get("content"):
                return self._format(matched["content"])

        # 3. Similar case resolution
        case = agent_results.get("SimilarCaseRetriever", {})
        if case.get("confidence", 0) >= 0.7:
            matched = case.get("result", {}).get("matched", {})
            if matched and matched.get("resolution"):
                return self._format(
                    f"根据历史类似案例（编号 {matched.get('id', 'N/A')}），处理方式如下：{matched['resolution']}"
                )

        # 4. Intent-based template fallback
        return self._intent_template(agent_results)

    def build_template_reply(self, agent_results: Dict[str, Any]) -> str:
        """
        Case B: Mixed confidence. Template + intent-driven reply.
        This will be polished by LLM in the chat service.
        """
        parts = []

        intent = agent_results.get("intent_classifier", {})
        intent_name = ""
        if isinstance(intent.get("result"), dict):
            intent_name = intent["result"].get("intent", "")
            label = intent["result"].get("label", "")
            parts.append(f"已理解您的{label}需求。")

        faq = agent_results.get("FAQRetriever", {})
        if faq.get("confidence", 0) >= 0.5:
            matched = faq.get("result", {}).get("matched", {})
            if matched and matched.get("answer"):
                parts.append(matched["answer"])

        policy = agent_results.get("PolicyMatcher", {})
        if policy.get("confidence", 0) >= 0.6:
            matched = policy.get("result", {}).get("matched", {})
            if matched and matched.get("content"):
                parts.append(f"根据相关规定：{matched['content'][:300]}")

        dialog = agent_results.get("dialogue_tracker", {})
        if isinstance(dialog.get("result"), dict):
            followup = dialog["result"].get("followup_prompt", "")
            if followup:
                parts.append(followup)

        if len(parts) <= 1:
            parts.append("请问还有什么可以帮您的？")

        return "\n\n".join(parts)

    def _intent_template(self, agent_results: Dict[str, Any]) -> str:
        intent = agent_results.get("intent_classifier", {})
        result = intent.get("result", {})
        if not isinstance(result, dict):
            return "已收到您的消息，请问还有什么可以帮您的？"

        intent_name = result.get("intent", "")
        templates = {
            "refund": "已收到您的退款请求。请提供相关信息，我会帮您核实处理。",
            "complaint": "非常抱歉给您带来不便。已记录您反映的问题，会尽快安排人员跟进。",
            "inquiry": "您咨询的问题已记录。如需进一步帮助，请提供更多详细信息。",
            "repair": "已收到您的报修请求。请提供具体情况和联系方式，以便安排人员处理。",
            "suggestion": "感谢您的宝贵建议，已记录并将反馈给相关负责人。",
            "dispute": "理解您的情况。邻里纠纷建议先冷静沟通，如需调解员介入可以帮您联系。",
            "elderly": "已记录老人关怀需求。会安排志愿者定期探访，请保持联系方式畅通。",
            "policy": "您咨询的政策问题已记录。建议同步向村委会或民政部门核实最新政策细节。",
            "farming": "已记录您的农技需求。会帮您对接农技站或相关专家，请留意后续联系。",
            "education": "理解您对孩子教育的关心。可以帮您联系支教资源或相关帮扶项目。",
            "emergency": "已收到紧急求助。请保持冷静，如涉及生命安全请先拨打120/110。志愿者会尽快响应。",
            "infrastructure": "已记录您反映的基础设施问题。会向村委会和乡镇相关部门反馈，推动纳入维修或建设计划。",
            "employment": "已记录您的就业/务工需求。可以帮您对接人社部门了解最新招聘和免费技能培训信息。",
            "medical": "已记录您的医疗健康问题。建议同时向村卫生室或乡镇卫生院咨询，我们可以帮您对接相关帮扶资源。",
            "environment": "已记录您反映的环境问题。农村人居环境改善需要大家共同参与，会向村委会和乡镇环卫部门反馈。",
        }
        return templates.get(intent_name, "已收到您的消息，请问还有什么可以帮您的？")

    def _format(self, text: str) -> str:
        swapped = system_to_user(text)
        return swapped.get("text", text)
