from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from .agent_registry import AgentRegistry
from .pipeline import PipelineRunner
from .response_builder import ResponseBuilder


class DispatchCase(str, Enum):
    A = "A"  # All confident → direct rule-based reply
    B = "B"  # Mixed → template + optional LLM polish
    C = "C"  # Low confidence / conflict / emotional → full LLM


@dataclass
class DispatchResult:
    case: DispatchCase
    reasoning: str
    agent_results: Dict[str, Any]
    final_reply: str
    should_escalate: bool = False
    function_calls: List[Dict] = field(default_factory=list)


class Dispatcher:
    """
    Dispatcher ("社工老王") — 3-phase pipeline + 3-case decision.

    Phase 1 (并行, ~10-50ms): Intent + Entity + Sentiment — 纯规则，零 LLM 成本
    Phase 2 (并行, ~50-200ms): Urgency + Dialog + FAQ + Case + Policy — 条件判断
    Phase 3 (决策):
      Case A: 所有关键 agent 置信度 >= 0.8, 意图明确, 无紧急/愤怒 → 规则秒回
      Case B: 默认情况 → 模板 + LLM 润色
      Case C: 意图低置信度 OR urgent 情感 OR critical 紧急度 OR agent 冲突 → 全量 LLM
    """

    def __init__(self, registry: AgentRegistry):
        self.registry = registry
        self.pipeline = PipelineRunner(registry)
        self.builder = ResponseBuilder()

    async def dispatch(
        self, text: str, session_id: str, context: Optional[Dict[str, Any]] = None
    ) -> DispatchResult:
        # Run Phase 1 + Phase 2
        pipe_output = await self.pipeline.run_full(text, session_id, context)
        results = pipe_output["results"]
        phase1 = pipe_output["phase1"]
        phase2 = pipe_output["phase2"]
        latency_ms = pipe_output["latency_ms"]

        # Decision
        case, reasoning = self._decide(results)

        # Build reply
        if case == DispatchCase.A:
            reply = self.builder.build_rule_reply(results)
        elif case == DispatchCase.B:
            reply = self.builder.build_template_reply(results)
        else:
            # Case C — caller must supply LLM reply
            reply = ""

        return DispatchResult(
            case=case,
            reasoning=reasoning,
            agent_results={
                "phase1": [self._serialize(r) for r in phase1],
                "phase2": [self._serialize(r) for r in phase2],
                "decision": {"case": case.value, "reasoning": reasoning},
                "latency_ms": latency_ms,
            },
            final_reply=reply,
            should_escalate=self._check_escalation(results),
        )

    def _decide(self, results: Dict[str, Any]) -> tuple[DispatchCase, str]:
        intent_r = results.get("intent_classifier", {})
        sentiment_r = results.get("sentiment_analyzer", {})
        urgency_r = results.get("urgency_assessor", {})
        faq_r = results.get("FAQRetriever", {})

        intent_conf = intent_r.get("confidence", 0)
        intent_name = ""
        sentiment_label = ""
        urgency_label = ""
        faq_conf = faq_r.get("confidence", 0)

        if isinstance(intent_r.get("result"), dict):
            intent_name = intent_r["result"].get("intent", "")
        if isinstance(sentiment_r.get("result"), dict):
            sentiment_label = sentiment_r["result"].get("sentiment", "")
        if isinstance(urgency_r.get("result"), dict):
            urgency_label = urgency_r["result"].get("urgency", "")

        # ── Case C triggers ──
        if sentiment_label == "urgent":
            return DispatchCase.C, "用户情绪标记为urgent，需大模型介入"
        if urgency_label == "critical":
            return DispatchCase.C, "紧急度评估为critical，需大模型介入"
        if intent_conf < 0.5:
            return DispatchCase.C, f"意图识别置信度过低({intent_conf:.2f})，需大模型介入"

        # Any critical agent with confidence < 0.3
        # FAQ/SimilarCase are optional (model-dependent), excluded from this check
        _OPTIONAL_AGENTS = {"FAQRetriever", "SimilarCaseRetriever"}
        low_conf_agents = [
            name for name, r in results.items()
            if name not in _OPTIONAL_AGENTS and r.get("confidence", 0) < 0.3
        ]
        if low_conf_agents:
            return DispatchCase.C, f"以下agent置信度过低: {', '.join(low_conf_agents)}"

        # ── Case A conditions ──
        if (
            intent_conf >= 0.8
            and intent_name != "other"
            and sentiment_label not in ("urgent",)
            and urgency_label not in ("critical",)
            and faq_conf >= 0.5
        ):
            return DispatchCase.A, "所有关键agent置信度高，规则可直接回复"

        # ── Default: Case C (LLM) ──
        # 非 Case A 全部走 LLM，适用于乡村志愿者场景：问题多样、规则覆盖不全
        return DispatchCase.C, "非高置信度场景，调用LLM生成回复"

    def _check_escalation(self, results: Dict[str, Any]) -> bool:
        urgency_r = results.get("urgency_assessor", {})
        if isinstance(urgency_r.get("result"), dict):
            if urgency_r["result"].get("urgency") == "critical":
                return True
        sentiment_r = results.get("sentiment_analyzer", {})
        if isinstance(sentiment_r.get("result"), dict):
            if sentiment_r["result"].get("sentiment") == "urgent":
                return True
        return False

    def _serialize(self, agent_result) -> Dict[str, Any]:
        return {
            "agent_name": agent_result.agent_name,
            "result": agent_result.result,
            "confidence": agent_result.confidence,
            "evidence": agent_result.evidence,
        }
