"""
Backend Orchestrator —— 桥接后端服务与 python/core Agent 编排层

替代旧 Dispatcher + Pipeline + ResponseBuilder 三件套。
"""
import logging
import sys
from pathlib import Path
from typing import Any, AsyncIterator, Dict, Optional

# 确保 python/ 在 path 中
_AGENTS_PATH = Path(__file__).resolve().parent.parent.parent.parent / "python"
if str(_AGENTS_PATH) not in sys.path:
    sys.path.insert(0, str(_AGENTS_PATH))

from core.tool_registry import ToolRegistry
from core.tool_schema import ToolSchema
from core.orchestrator import AgentOrchestrator
from core.llm_client import AgentLLMClient
from core.memory import EpisodicMemory
from agents.llm_tools import ALL_TOOLS, set_llm_client
from ..config import settings

logger = logging.getLogger(__name__)

_orchestrator: Optional[AgentOrchestrator] = None


def get_orchestrator() -> AgentOrchestrator:
    global _orchestrator
    if _orchestrator is None:
        # 初始化 LLM 客户端
        llm = AgentLLMClient(
            api_key=settings.openai_api_key,
            base_url=settings.openai_base_url,
            model=settings.model_name,
        )

        # 注入 LLM 到工具层
        set_llm_client(llm, use_llm=bool(settings.openai_api_key))

        # 注册所有工具
        tool_registry = ToolRegistry()
        for tool_def in ALL_TOOLS:
            schema = ToolSchema(
                name=tool_def["name"],
                description=tool_def["description"],
                category=tool_def["category"],
                trigger_keywords=tool_def.get("trigger_keywords", []),
                parameters=tool_def.get("parameters", {}),
                required=tool_def.get("required", []),
                fn=tool_def["fn"],
                cost_estimate=tool_def.get("cost_estimate", "low"),
            )
            tool_registry.register_raw(schema)

        # 初始化情节记忆（持久化到文件）
        memory_db = str(Path(settings.database_url.replace("sqlite+aiosqlite:///", "")).parent / "memory.db")
        if "feedback.db" in memory_db:
            memory_db = memory_db.replace("feedback.db", "memory.db")

        _orchestrator = AgentOrchestrator(
            tool_registry=tool_registry,
            llm_client=llm,
            memory_db_path=memory_db,
        )
        logger.info(f"AgentOrchestrator initialized: {len(tool_registry)} tools, "
                     f"LLM={llm.model} @ {llm.base_url}, "
                     f"available={llm.available}")
    return _orchestrator


class OrchestratorService:
    """Orchestrator 服务层 —— 供 ChatService 调用"""

    def __init__(self):
        self._orchestrator = get_orchestrator()

    async def process_message(
        self, text: str, session_id: str, context: Dict = None
    ) -> Dict[str, Any]:
        """处理用户消息，返回完整结果"""
        return await self._orchestrator.process(text, session_id, context)

    async def process_stream(
        self, text: str, session_id: str, context: Dict = None
    ) -> AsyncIterator[Dict]:
        """流式处理用户消息"""
        async for event in self._orchestrator.process_stream(text, session_id, context):
            yield event

    def get_session_context(self, session_id: str) -> Dict[str, Any]:
        return self._orchestrator.get_session_context(session_id)
