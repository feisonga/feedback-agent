import logging
import os
from pathlib import Path
from typing import Optional

from agents import AgentResult
from agents.intent_classifier import IntentClassifier
from agents.entity_extractor import EntityExtractor
from agents.sentiment_analyzer import SentimentAnalyzer
from agents.urgency_assessor import UrgencyAssessor
from agents.dialogue_tracker import DialogTracker
from agents.faq_retriever import FAQRetriever
from agents.similar_case import SimilarCaseRetriever
from agents.policy_matcher import PolicyMatcher

logger = logging.getLogger(__name__)


class _StubRetriever:
    """Fallback when sentence-transformers model is unavailable."""
    def __init__(self, name: str):
        self.name = name

    def process(self, text: str, context: dict = None) -> AgentResult:
        return AgentResult(
            agent_name=self.name,
            result={"matched": None, "candidates": []},
            confidence=0.0,
            evidence=["模型未加载，无法检索"],
        )


class AgentRegistry:
    """Loads and manages all 8 symbolic agents."""

    def __init__(self, kb_path: Path, model_name: str = "paraphrase-multilingual-MiniLM-L12-v2"):
        kb = str(kb_path)
        self._embedding_model = None

        # ── Always-available agents (regex/dict-based, zero external deps) ──
        self.intent = IntentClassifier(patterns_path=os.path.join(kb, "intent_patterns.yaml"))
        self.entity = EntityExtractor(patterns_path=os.path.join(kb, "entity_patterns.yaml"))
        self.sentiment = SentimentAnalyzer(dict_path=os.path.join(kb, "sentiment_dict.json"))
        self.urgency = UrgencyAssessor(dict_path=os.path.join(kb, "sentiment_dict.json"))
        self.dialogue = DialogTracker()
        self.policy = PolicyMatcher(
            docs_dir=os.path.join(kb, "policy_docs"),
            index_dir=os.path.join(kb, "policy_index"),
        )

        # ── Optional agents (need sentence-transformers) ──
        self.faq = self._init_faq(kb, model_name)
        self.similar_case = self._init_similar_case(model_name)

        self._phase1_agents = [self.intent, self.entity, self.sentiment]
        self._phase2_agents = [self.urgency, self.dialogue, self.faq, self.similar_case, self.policy]

    def _load_embedding_model(self, model_name: str):
        if self._embedding_model is not None:
            return self._embedding_model
        try:
            import os as _os
            _os.environ.setdefault("HF_HUB_OFFLINE", "1")
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer(model_name, local_files_only=True)
            self._embedding_model = model
            logger.info(f"Embedding model loaded: {model_name}")
            return model
        except Exception as e:
            logger.warning(f"Cannot load embedding model '{model_name}': {e}")
            logger.warning("FAQ and SimilarCase retrievers will return empty results")
            return None

    def _init_faq(self, kb: str, model_name: str):
        try:
            model = self._load_embedding_model(model_name)
            if model is None:
                return _StubRetriever("FAQRetriever")
            faq = FAQRetriever(corpus_path=os.path.join(kb, "faq_corpus.json"), model_name=None)
            faq.model = model
            faq._load_corpus()
            faq._build_index()
            return faq
        except Exception as e:
            logger.warning(f"FAQRetriever init failed: {e}")
            return _StubRetriever("FAQRetriever")

    def _init_similar_case(self, model_name: str):
        try:
            model = self._embedding_model
            if model is None:
                model = self._load_embedding_model(model_name)
            if model is None:
                return _StubRetriever("SimilarCaseRetriever")
            from agents.similar_case import SAMPLE_CASES
            sc = SimilarCaseRetriever(model_name=None)
            sc.model = model
            sc.cases = list(SAMPLE_CASES)
            sc._build_index()
            return sc
        except Exception as e:
            logger.warning(f"SimilarCaseRetriever init failed: {e}")
            return _StubRetriever("SimilarCaseRetriever")

    @property
    def model_available(self) -> bool:
        return self._embedding_model is not None

    def get(self, name: str):
        mapping = {
            "intent_classifier": self.intent,
            "entity_extractor": self.entity,
            "sentiment_analyzer": self.sentiment,
            "urgency_assessor": self.urgency,
            "dialogue_tracker": self.dialogue,
            "faq_retriever": self.faq,
            "similar_case": self.similar_case,
            "policy_matcher": self.policy,
        }
        return mapping.get(name)


_registry: Optional[AgentRegistry] = None


def get_agent_registry(kb_path: Optional[Path] = None) -> AgentRegistry:
    global _registry
    if _registry is None:
        if kb_path is None:
            from ..config import settings
            kb_path = settings.resolved_kb_path
        _registry = AgentRegistry(kb_path)
    return _registry
