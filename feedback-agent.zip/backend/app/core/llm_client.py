import json
import logging
from typing import Any, AsyncIterator, Dict, Optional

from openai import AsyncOpenAI

from ..config import settings

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """你是乡村社区服务助手，专门为乡村志愿者和村民提供帮助。当规则系统无法确定回答时，由你来生成回复。

## 你的角色
你是"社工老王"调度中心背后的专家顾问，服务对象是乡村社区的志愿者和村民。

## 回复风格
- 亲切、朴实、有温度，像邻里之间的对话
- 使用"您"称谓，但语气自然不生硬
- 理解乡村生活的实际情况，给出的建议要落地可行
- 村民情绪激动时要先安抚，再给方案
- 志愿者咨询工作方法时要鼓励支持

## 回复要求
- 先共情，理解对方处境
- 再给方案，步骤清晰、可操作
- 最后收尾，表达持续支持
- 不要承诺超出社区服务范围的事情
- 不确定的事情诚实说"不确定"，不要编造
- 涉及政策补贴、法律问题时注明"建议进一步咨询相关部门"

## 乡村志愿者常见场景
- 村民纠纷调解
- 孤寡老人关怀
- 低保/补贴政策咨询
- 农技服务对接
- 儿童教育帮扶
- 突发困难求助
- 社区活动组织

## 领域知识库（三农与农村问题权威参考）
以下信息来自中国政府网、共产党员网、中央一号文件及权威三农研究文献，请在回答相关问题时严格以此为据。

### 基础概念
- "三农"：农业（生产产业）+ 农村（空间社会）+ 农民（主体人群），三者整体性统称，是关系国计民生的根本性问题。
- 农民是核心主体，农业是生存产业，农村是生存空间。城乡二元结构是三农问题的底层根源。
- 概念起源：1996年温铁军正式提出，2003年中央农村工作会议写入官方表述，2004年起中央一号文件连续聚焦三农。

### 核心数据（截至2024-2025）
- 粮食总产量：稳定1.4万亿斤以上，谷物自给率超95%，口粮绝对安全。
- 农村居民人均可支配收入：23119元（2024年），实际增速6.3%，快于城镇居民1.9个百分点。
- 城乡居民收入比：2.34:1，持续缩小。
- 脱贫务工规模：超3300万人。
- 高标准农田：累计建成超10亿亩。
- 常住人口城镇化率：突破66%，农村老龄化持续加深。

### 国家政策框架
- 总抓手：乡村振兴战略；总目标：农业农村现代化；总方针：农业农村优先发展。
- 两条底线：保障粮食安全、不发生规模性返贫。
- 五大振兴：产业振兴（重中之重）、人才振兴、文化振兴、生态振兴、组织振兴。
- 关键文件：中央一号文件（2004-2026连续发布）、《乡村全面振兴规划（2024-2027年）》、《乡村振兴促进法》、"千万工程"经验。
- 土地制度：三权分置（所有权归集体、承包权归农户、经营权可流转）、高标准农田建设、宅基地盘活。
- 惠农政策：种粮补贴（耕地地力保护补贴）、农机购置补贴、农业保险补贴、最低收购价政策。

### 当前突出矛盾
1. 城乡发展不平衡、农村发展不充分是最突出矛盾。
2. 农村人口老龄化、空心化持续加剧，青壮年劳动力外流。
3. 村集体经济发展不均衡，大量薄弱村缺少稳定增收渠道。
4. 农业生产成本持续走高，农业比较收益偏低，农民种粮积极性承压。
5. 乡村公共服务长效运营机制缺失，重建设轻管护问题普遍。
6. 乡土文明建设滞后，高价彩礼、大操大办等移风易俗任务繁重。
7. 农业防灾减灾体系不完善，极端天气、病虫害风险突出。
8. 城乡二元体制遗留问题未完全破除，户籍、土地、社保制度仍需深化改革。

### 十大热点问题处理方向
1. 空心村与留守群体：网格化管理+互助养老+志愿者结对探访+社工介入。
2. 高价彩礼与大操大办：村规民约+红白理事会+党员干部带头+文明实践。
3. 耕地非粮化非农化：严格耕地保护制度+撂荒地复垦+用途管制。
4. 宅基地盘活：出租+合作经营+自愿有偿退出，严禁城镇居民下乡购买宅基地。
5. 村集体经济增收：盘活闲置资源+发展特色产业+提供生产服务+光伏电站+承接小型工程。
6. 农村养老与医疗：村级养老服务站+县域医共体+村卫生室标准化+医保直接结算。
7. 农产品销售：对接批发市场+电商平台+合作社+订单农业+832扶贫采购平台。
8. 返乡创业扶持：创业担保贷款（20-30万）+一次性补贴+税收优惠+用地支持+免费培训。
9. 防止返贫监测：监测线约7500-8000元/年，自主申报+村委排查+产业就业帮扶。
10. 传统村落保护：申报传统村落名录+文保单位+非遗项目+保护优先适度开发。

请基于以上知识库内容回答用户问题，确保政策信息准确、建议可行落地。"""


class LLMClient:
    """OpenAI-compatible LLM wrapper for Case C generation."""

    def __init__(self, api_key: str = "", base_url: str = "", model: str = ""):
        self.api_key = api_key or settings.openai_api_key
        self.base_url = base_url or settings.openai_base_url
        self.model = model or settings.model_name
        self._client: Optional[AsyncOpenAI] = None

    @property
    def client(self) -> AsyncOpenAI:
        if self._client is None:
            self._client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
            )
        return self._client

    @property
    def available(self) -> bool:
        return bool(self.api_key)

    def _build_user_prompt(self, user_text: str, agent_results: Dict[str, Any]) -> str:
        """Build a structured prompt from agent results for the LLM."""
        parts = [f"## 用户当前消息\n{user_text}\n"]

        # Phase 1 results
        for item in agent_results.get("phase1", []):
            name = item.get("agent_name", "")
            result = item.get("result", {})
            conf = item.get("confidence", 0)
            if name == "intent_classifier" and isinstance(result, dict):
                parts.append(f"## 意图分析（置信度 {conf:.0%}）\n- 意图: {result.get('intent', '?')} ({result.get('label', '?')})")
            elif name == "sentiment_analyzer" and isinstance(result, dict):
                parts.append(f"## 情感分析（置信度 {conf:.0%}）\n- 情感: {result.get('sentiment', '?')}，强度: {result.get('intensity', 0):.2f}")
            elif name == "entity_extractor" and isinstance(result, dict):
                entities = result.get("entities", {})
                if entities:
                    parts.append(f"## 提取实体\n{json.dumps(entities, ensure_ascii=False)}")

        # Phase 2 results
        for item in agent_results.get("phase2", []):
            name = item.get("agent_name", "")
            result = item.get("result", {})
            if name == "urgency_assessor" and isinstance(result, dict):
                parts.append(f"## 紧急度评估\n- 级别: {result.get('urgency', '?')}，分数: {result.get('score', 0):.2f}")
            elif name == "PolicyMatcher" and isinstance(result, dict):
                matched = result.get("matched", {})
                if matched and matched.get("content"):
                    parts.append(f"## 相关政策\n{matched['content'][:500]}")
            elif name == "SimilarCaseRetriever" and isinstance(result, dict):
                matched = result.get("matched", {})
                if matched and matched.get("resolution"):
                    parts.append(f"## 相似历史案例\n案例: {matched.get('description', '')}\n处理方式: {matched['resolution']}")

        # Decision
        decision = agent_results.get("decision", {})
        parts.append(f"\n## 调度决策\n- 分流: Case {decision.get('case', '?')}\n- 原因: {decision.get('reasoning', '?')}")

        parts.append("\n请基于以上信息生成客服回复。")
        return "\n".join(parts)

    async def generate_reply(
        self, user_text: str, agent_results: Dict[str, Any], history: list = None
    ) -> str:
        """Non-streaming: generate a full reply."""
        if not self.available:
            return self._fallback_reply(agent_results)

        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": self._build_user_prompt(user_text, agent_results)})

        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.7,
                max_tokens=1024,
            )
            return response.choices[0].message.content or ""
        except Exception as e:
            logger.error(f"LLM call failed: {e}")
            return self._fallback_reply(agent_results)

    async def generate_stream(
        self, user_text: str, agent_results: Dict[str, Any], history: list = None
    ) -> AsyncIterator[str]:
        """Streaming: yield tokens one at a time."""
        if not self.available:
            yield self._fallback_reply(agent_results)
            return

        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": self._build_user_prompt(user_text, agent_results)})

        try:
            stream = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.7,
                max_tokens=1024,
                stream=True,
            )
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            logger.error(f"LLM stream failed: {e}")
            yield self._fallback_reply(agent_results)

    def _fallback_reply(self, agent_results: Dict[str, Any]) -> str:
        """Graceful degradation when LLM is unavailable."""
        intent_name = ""
        for item in agent_results.get("phase1", []):
            if item.get("agent_name") == "intent_classifier" and isinstance(item.get("result"), dict):
                intent_name = item["result"].get("label", "")
        if intent_name:
            return f"已收到您的{intent_name}需求，正在为您转接人工客服，请稍候。"
        return "已收到您的消息，正在为您转接人工客服，请稍候。"


_client: Optional[LLMClient] = None


def get_llm_client() -> LLMClient:
    global _client
    if _client is None:
        _client = LLMClient()
    return _client
