"""
ChatService —— 使用 LLM-native AgentOrchestrator 处理消息

ReAct 推理链路通过 WebSocket 实时推送至前端。
"""
import time
import uuid
from datetime import datetime
from typing import AsyncIterator, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from ..models.conversation import Conversation, Message
from ..core.orchestrator import OrchestratorService


class ChatService:
    """LLM-native 智能客服消息处理服务"""

    def __init__(self, db: AsyncSession):
        self.db = db
        self.orchestrator = OrchestratorService()

    async def process_message(
        self, session_id: str, text: str, context: dict | None = None
    ) -> dict:
        """非流式处理"""
        t0 = time.perf_counter()

        result = await self.orchestrator.process_message(text, session_id, context)

        # 持久化
        await self._persist_messages(session_id, text, result["reply"], result["agent_trace"])
        latency_ms = int((time.perf_counter() - t0) * 1000)

        return {
            "message_id": str(uuid.uuid4()),
            "session_id": session_id,
            "reply": result["reply"],
            "case": "llm_react",
            "intent": self._extract_from_trace(result["agent_trace"], "intent"),
            "sentiment": self._extract_from_trace(result["agent_trace"], "sentiment"),
            "urgency": self._extract_from_trace(result["agent_trace"], "urgency"),
            "agent_trace": {**result["agent_trace"], "latency_ms": latency_ms},
        }

    async def process_stream(
        self, session_id: str, text: str, context: dict | None = None
    ) -> AsyncIterator[dict]:
        """流式处理 + ReAct 事件推送"""
        t0 = time.perf_counter()
        final_reply = ""
        tool_calls = []

        async for event in self.orchestrator.process_stream(text, session_id, context):
            if event["type"] == "react_step":
                for tc in event.get("tool_calls", []):
                    tool_calls.append(tc["name"])
            elif event["type"] == "message_complete":
                final_reply = event["reply"]
                event["latency_ms"] = int((time.perf_counter() - t0) * 1000)
            yield event

        # 持久化
        await self._persist_messages(session_id, text, final_reply, event.get("agent_trace", {
            "steps": [],
            "total_tool_calls": len(tool_calls),
        }))

    async def _persist_messages(
        self, session_id: str, user_text: str, reply: str, agent_trace: dict
    ):
        """持久化用户和助手消息"""
        conv_id = await self._resolve_conversation_id(session_id)

        user_msg = Message(
            id=str(uuid.uuid4()),
            conversation_id=conv_id,
            role="user",
            content=user_text,
            created_at=datetime.utcnow(),
        )
        self.db.add(user_msg)

        assistant_msg = Message(
            id=str(uuid.uuid4()),
            conversation_id=conv_id,
            role="assistant",
            content=reply,
            intent=self._extract_from_trace(agent_trace, "intent"),
            sentiment=self._extract_from_trace(agent_trace, "sentiment"),
            urgency=self._extract_from_trace(agent_trace, "urgency"),
            agent_trace=agent_trace,
            dispatch_case="llm_react",
            latency_ms=agent_trace.get("total_latency_ms", 0),
            created_at=datetime.utcnow(),
        )
        self.db.add(assistant_msg)

        # 更新对话标题
        try:
            from sqlalchemy import select
            conv = (await self.db.execute(
                select(Conversation).where(Conversation.id == conv_id)
            )).scalar_one_or_none()
            if conv and conv.title == "新对话":
                conv.title = user_text[:50]
                conv.updated_at = datetime.utcnow()
        except Exception:
            pass

        await self.db.commit()

    async def _resolve_conversation_id(self, session_id: str) -> str:
        from sqlalchemy import select
        from ..models.session_model import ChatSession
        result = await self.db.execute(
            select(ChatSession).where(ChatSession.id == session_id)
        )
        sess = result.scalar_one_or_none()
        if sess:
            return sess.conversation_id
        # 创建新对话
        conv = Conversation(
            id=str(uuid.uuid4()),
            title="新对话",
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        self.db.add(conv)
        new_sess = ChatSession(
            id=session_id,
            conversation_id=conv.id,
            created_at=datetime.utcnow(),
        )
        self.db.add(new_sess)
        await self.db.commit()
        return conv.id

    def _extract_from_trace(self, agent_trace: dict, key: str) -> str | None:
        """从 agent_trace 中提取上下文变量"""
        for step in agent_trace.get("steps", []):
            for obs in step.get("observations", []):
                data = obs.get("data", {})
                if isinstance(data, dict):
                    if key == "intent" and "intent" in data:
                        return data["intent"]
                    if key == "sentiment" and "sentiment" in data:
                        return data["sentiment"]
                    if key == "urgency" and "urgency" in data:
                        return data["urgency"]
        return None
