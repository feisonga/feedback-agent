from datetime import datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from ..models.conversation import Conversation, Message
from ..models.analytics_models import AnalyticsEvent


class AnalyticsService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def overview(self, days: int = 30) -> dict:
        since = datetime.utcnow() - timedelta(days=days)

        # Total sessions (= conversations since we create one per session)
        total_sessions_result = await self.db.execute(
            select(func.count(Conversation.id)).where(Conversation.created_at >= since)
        )
        total_sessions = total_sessions_result.scalar() or 0

        # Total messages
        total_messages_result = await self.db.execute(
            select(func.count(Message.id)).where(Message.created_at >= since)
        )
        total_messages = total_messages_result.scalar() or 0

        # Case distribution
        case_a_result = await self.db.execute(
            select(func.count(Message.id)).where(
                Message.dispatch_case == "A", Message.created_at >= since
            )
        )
        case_a = case_a_result.scalar() or 0

        case_b_result = await self.db.execute(
            select(func.count(Message.id)).where(
                Message.dispatch_case == "B", Message.created_at >= since
            )
        )
        case_b = case_b_result.scalar() or 0

        case_c_result = await self.db.execute(
            select(func.count(Message.id)).where(
                Message.dispatch_case == "C", Message.created_at >= since
            )
        )
        case_c = case_c_result.scalar() or 0

        # Average latency
        avg_latency_result = await self.db.execute(
            select(func.avg(Message.latency_ms)).where(
                Message.role == "assistant", Message.created_at >= since
            )
        )
        avg_latency = avg_latency_result.scalar() or 0

        # Intent distribution
        intent_result = await self.db.execute(
            select(Message.intent, func.count(Message.id))
            .where(Message.intent.isnot(None), Message.created_at >= since)
            .group_by(Message.intent)
        )
        intent_dist = {row[0]: row[1] for row in intent_result.all()}

        # Sentiment distribution
        sentiment_result = await self.db.execute(
            select(Message.sentiment, func.count(Message.id))
            .where(Message.sentiment.isnot(None), Message.created_at >= since)
            .group_by(Message.sentiment)
        )
        sentiment_dist = {row[0]: row[1] for row in sentiment_result.all()}

        total_assistant = case_a + case_b + case_c

        return {
            "total_sessions": total_sessions,
            "total_messages": total_messages,
            "avg_latency_ms": round(float(avg_latency), 1),
            "case_distribution": {
                "case_a": case_a,
                "case_b": case_b,
                "case_c": case_c,
                "case_a_pct": round(case_a / total_assistant * 100, 1) if total_assistant else 0,
                "case_b_pct": round(case_b / total_assistant * 100, 1) if total_assistant else 0,
                "case_c_pct": round(case_c / total_assistant * 100, 1) if total_assistant else 0,
            },
            "intent_distribution": intent_dist,
            "sentiment_distribution": sentiment_dist,
        }

    async def agent_performance(self, days: int = 30) -> list[dict]:
        since = datetime.utcnow() - timedelta(days=days)

        result = await self.db.execute(
            select(Message).where(
                Message.role == "assistant",
                Message.created_at >= since,
                Message.agent_trace.isnot(None),
            ).limit(200)
        )
        messages = result.scalars().all()

        agent_stats: dict[str, dict] = {}
        for msg in messages:
            trace = msg.agent_trace or {}
            for phase_key in ("phase1", "phase2"):
                for item in trace.get(phase_key, []):
                    name = item.get("agent_name", "unknown")
                    conf = item.get("confidence", 0)
                    if name not in agent_stats:
                        agent_stats[name] = {
                            "agent_name": name,
                            "total_calls": 0,
                            "avg_confidence": 0.0,
                            "confidence_sum": 0.0,
                            "cases": {"A": 0, "B": 0, "C": 0},
                        }
                    agent_stats[name]["total_calls"] += 1
                    agent_stats[name]["confidence_sum"] += conf
                    if msg.dispatch_case:
                        agent_stats[name]["cases"][msg.dispatch_case] = (
                            agent_stats[name]["cases"].get(msg.dispatch_case, 0) + 1
                        )

        for stats in agent_stats.values():
            if stats["total_calls"]:
                stats["avg_confidence"] = round(stats["confidence_sum"] / stats["total_calls"], 3)

        return sorted(agent_stats.values(), key=lambda x: x["total_calls"], reverse=True)

    async def record_event(self, event_type: str, payload: dict | None = None):
        event = AnalyticsEvent(event_type=event_type, payload=payload)
        self.db.add(event)
        await self.db.commit()
