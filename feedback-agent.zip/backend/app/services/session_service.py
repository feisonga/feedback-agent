import json
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from ..models.conversation import Conversation
from ..models.session_model import ChatSession


class SessionService:
    """Manages chat session lifecycle and DialogTracker state persistence."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, user_id: str | None = None) -> dict:
        conv_id = str(uuid.uuid4())
        session_id = str(uuid.uuid4())
        now = datetime.utcnow()

        conv = Conversation(id=conv_id, title="新对话", user_id=user_id, created_at=now, updated_at=now)
        sess = ChatSession(id=session_id, conversation_id=conv_id, state={}, created_at=now)

        self.db.add(conv)
        self.db.add(sess)
        await self.db.commit()

        return {
            "session_id": session_id,
            "conversation_id": conv_id,
            "created_at": now.isoformat(),
        }

    async def get(self, session_id: str) -> Optional[ChatSession]:
        result = await self.db.execute(select(ChatSession).where(ChatSession.id == session_id))
        return result.scalar_one_or_none()

    async def get_state(self, session_id: str) -> dict:
        sess = await self.get(session_id)
        if sess is None:
            return {}
        return sess.state or {}

    async def save_state(self, session_id: str, state: dict):
        sess = await self.get(session_id)
        if sess:
            sess.state = state
            await self.db.commit()

    async def get_conversation(self, session_id: str) -> Optional[Conversation]:
        sess = await self.get(session_id)
        if sess is None:
            return None
        result = await self.db.execute(select(Conversation).where(Conversation.id == sess.conversation_id))
        return result.scalar_one_or_none()
