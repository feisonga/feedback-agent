"""
Integration test: run 10 test messages through the dispatcher pipeline.
Verifies Case A/B/C classification without needing the HTTP server.
"""
import os as _os
_os.environ.setdefault("HF_HUB_OFFLINE", "1")

import asyncio
import sys
from pathlib import Path

# Ensure python/ is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "python"))

from app.core.agent_registry import AgentRegistry
from app.core.dispatcher import Dispatcher, DispatchCase

KB_PATH = Path(__file__).resolve().parent.parent.parent / "python" / "knowledge"

TEST_CASES = [
    # (text, expected_case_hint)
    ("我要退款，订单号ORD-8848，买了三天了", "A"),       # clear intent + order_id
    ("你们的产品质量太差了，我要投诉！", "B"),            # complaint, strong sentiment
    ("这个订单什么时候能到货啊", "A"),                    # inquiry, simple
    ("我要是不退款我就去工商局告你们！", "C"),           # threat = urgent/critical
    ("你们这个破玩意，气死我了，赶紧给我退了", "C"),     # strong anger = urgent sentiment
    ("你好，我想问一下退货政策是怎么规定的", "A"),       # inquiry, policy match likely
    ("我今天心情不太好，就是想找个人聊聊", "C"),         # unclear intent
    ("上次那个工单处理完了吗，TK-12345678", "B"),        # ticket inquiry, medium confidence
    ("你们的客服态度简直令人发指", "B"),                 # complaint, strong negative
    ("帮我查一下产品库存", "A"),                         # inquiry, simple
]


async def main():
    print("=" * 60)
    print("Feedback Agent Dispatcher Integration Test")
    print("=" * 60)

    print("\n[1/3] Loading AgentRegistry...")
    registry = AgentRegistry(KB_PATH)
    print(f"  Loaded {len(registry._phase1_agents) + len(registry._phase2_agents)} agents")

    print("\n[2/3] Creating Dispatcher...")
    dispatcher = Dispatcher(registry)
    print("  Dispatcher ready")

    print("\n[3/3] Running test cases...\n")
    passed = 0
    for i, (text, hint) in enumerate(TEST_CASES, 1):
        result = await dispatcher.dispatch(text, f"test-session-{i}")
        case = result.case.value
        ok = (case == hint or hint == "?")
        status = "OK" if ok else "??"
        if ok:
            passed += 1
        print(f"  [{status}] Case #{i}: \"{text[:40]}...\"")
        print(f"       -> {case} (expected ~{hint}) | escalate={result.should_escalate}")
        print(f"       -> reason: {result.reasoning}")
        print(f"       -> latency: {result.agent_results.get('latency_ms', '?')}ms")
        if result.final_reply:
            print(f"       -> reply: {result.final_reply[:80]}...")
        print()

    print(f"\n  Results: {passed}/{len(TEST_CASES)} expected matches")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
