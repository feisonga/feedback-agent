@echo off
chcp 65001 >nul
title 停止 Feedback Agent

echo 正在停止 Feedback Agent...
echo.

taskkill /FI "WINDOWTITLE eq Feedback-Backend*" /T /F 2>nul
if %errorlevel%==0 (echo [√] 后端已停止) else (echo [-] 后端未在运行)

taskkill /FI "WINDOWTITLE eq Feedback-Frontend*" /T /F 2>nul
if %errorlevel%==0 (echo [√] 前端已停止) else (echo [-] 前端未在运行)

echo.
echo 所有服务已停止。
pause
