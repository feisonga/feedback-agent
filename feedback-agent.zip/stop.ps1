Write-Host "Stopping Feedback Agent..." -ForegroundColor Cyan

Get-Job -Name "FeedbackBackend" | Stop-Job -PassThru | Remove-Job -Force 2>$null
Write-Host "[OK] Backend stopped" -ForegroundColor Green

Get-Job -Name "FeedbackFrontend" | Stop-Job -PassThru | Remove-Job -Force 2>$null
Write-Host "[OK] Frontend stopped" -ForegroundColor Green

Write-Host "Done." -ForegroundColor Cyan
