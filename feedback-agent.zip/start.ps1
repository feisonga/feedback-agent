$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host "Feedback Agent - Starting..." -ForegroundColor Cyan

# Backend
Write-Host "[1/2] Starting backend on port 3100..." -ForegroundColor Yellow
$env:HF_HUB_OFFLINE = "1"
$backendJob = Start-Job -Name "FeedbackBackend" -ScriptBlock {
    Set-Location $using:root
    python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 3100
}

Write-Host "       Waiting 10s for model to load..." -ForegroundColor Gray
Start-Sleep -Seconds 10

# Frontend
Write-Host "[2/2] Starting frontend on port 5173..." -ForegroundColor Yellow
$frontendJob = Start-Job -Name "FeedbackFrontend" -ScriptBlock {
    Set-Location "$using:root\frontend"
    npm run dev
}

Write-Host ""
Write-Host "Backend:  http://localhost:3100" -ForegroundColor Green
Write-Host "Frontend: http://localhost:5173" -ForegroundColor Green
Write-Host "Docs:     http://localhost:3100/docs" -ForegroundColor Green
Write-Host ""
Write-Host "Run .\stop.ps1 to shut down." -ForegroundColor Gray
Write-Host "Run Receive-Job -Name FeedbackBackend to see backend logs." -ForegroundColor Gray
