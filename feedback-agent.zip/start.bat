@echo off
title Feedback Agent Launcher

echo Feedback Agent - Starting...

set ROOT=%~dp0

echo [1/2] Starting backend on port 3100...
start "Feedback-Backend" cmd /c "cd /d %ROOT% && HF_HUB_OFFLINE=1 python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 3100"

echo Waiting for backend to be ready...
timeout /t 10 /nobreak

echo [2/2] Starting frontend on port 5173...
start "Feedback-Frontend" cmd /c "cd /d %ROOT%frontend && npm run dev"

echo.
echo Backend:  http://localhost:3100
echo Frontend: http://localhost:5173
echo Docs:     http://localhost:3100/docs
echo.
echo Run stop.bat to shut down.
pause
