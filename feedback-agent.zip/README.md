# Feedback Agent · 智能客服反馈系统

**规则优先、AI 兜底** — 80% 常见问题靠规则毫秒级回复，20% 疑难问题交 LLM 深度处理。

## 架构

```
用户消息 → 3 阶段 Pipeline → "社工老王" 调度 → Case A/B/C → 生成回复
              │                      │
    Phase1: 3 agent 并行      Case A: 规则直出 (60%)
    Phase2: 5 agent 条件并行   Case B: 模板+润色 (20%)
                              Case C: LLM 生成 (20%)
```

8 个 Agent：意图识别 · 实体提取 · 情感分析 · 紧急度评估 · FAQ 检索 · 政策匹配 · 相似案例 · 对话追踪

## 技术栈

| 层 | 技术 |
|---|---|
| 后端 | Python 3.12 + FastAPI + SQLAlchemy 2.0 async + SQLite |
| 前端 | React 18 + Vite + Tailwind CSS 3 + TanStack Query 5 |
| 模型 | sentence-transformers (paraphrase-multilingual-MiniLM-L12-v2) |
| LLM | OpenAI 兼容 API (DeepSeek / Gemini) |

## 快速启动

### 本地开发

```bash
# 后端 (需要 Python 3.12)
pip install -e backend/
HF_HUB_OFFLINE=1 python -m uvicorn backend.app.main:app --port 3100 --reload

# 前端 (需要 Node 22)
cd frontend && npm install && npm run dev
# → http://localhost:5173
```

### Docker 一键启动

```bash
docker compose up -d
# → http://localhost
```

## API 路由

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/health` | 健康检查 + agent 加载状态 |
| POST | `/api/sessions` | 创建会话 |
| GET | `/api/sessions/{id}` | 获取会话详情 |
| POST | `/api/chat/send` | 发送消息 (REST) |
| WS | `/ws/chat/{id}` | 流式对话 (WebSocket) |
| GET | `/api/conversations` | 对话列表 |
| GET | `/api/conversations/{id}` | 对话详情 + 消息 |
| DELETE | `/api/conversations/{id}` | 删除对话 |
| GET | `/api/analytics/overview` | 分析概览 |
| GET | `/api/analytics/agent-performance` | Agent 性能统计 |

## 项目结构

```
feedback-agent/
├── backend/                     # FastAPI 应用
│   ├── app/
│   │   ├── main.py              # 入口 + lifespan
│   │   ├── config.py            # Pydantic Settings
│   │   ├── api/                 # REST + WebSocket 路由
│   │   ├── core/                # 调度器 · Pipeline · LLM 客户端
│   │   ├── models/              # SQLAlchemy ORM
│   │   ├── schemas/             # Pydantic 模型
│   │   └── services/            # 业务服务层
│   └── tests/
├── frontend/                    # React SPA
│   └── src/
│       ├── pages/               # ChatPage · AnalyticsPage
│       ├── components/          # ChatWindow · AgentTracePanel · Sidebar
│       ├── hooks/               # useChat · useChatStream · useAgentTrace
│       ├── api/                 # API client + endpoints
│       └── types/              # TypeScript 类型定义
├── python/                      # Agent 模块 + 知识库
│   ├── agents/                  # 8 个 agent
│   ├── knowledge/               # YAML/JSON/TXT 知识库
│   ├── capabilities/            # 功能注册 + 路由
│   └── functions/               # 订单/工单/客户操作
├── docker-compose.yml
└── README.md
```

## Case 决策逻辑

```
Case A (规则直出):
  意图置信度 >= 0.8 且 意图 != "other"
  且 FAQ/Policy 有匹配
  且无 urgent/critical 情绪
  → FAQ > Policy > Case > 模板，零 LLM 成本

Case B (模板+润色):
  默认情况
  → 模板拼装 + 可选 LLM 润色

Case C (LLM 生成):
  情感 = urgent 或 紧急度 = critical
  或 意图置信度 < 0.5
  或 核心 agent 置信度 < 0.3
  → 全量 LLM 生成回复
```
